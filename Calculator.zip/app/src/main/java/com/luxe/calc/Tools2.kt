package com.luxe.calc

import android.app.DatePickerDialog
import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.Period
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

fun num(s: String): Double = s.replace(",", "").trim().toDoubleOrNull() ?: 0.0

fun money(v: Double): String {
    val a = Math.abs(v)
    return (if (v < 0) "-" else "") + "₹" + pretty(String.format(Locale.US, if (a >= 1000) "%.0f" else "%.2f", a))
}

@Composable
fun rememberRoll(key: Double): Float {
    val a = remember { Animatable(1f) }
    LaunchedEffect(key) {
        a.snapTo(0.92f)
        a.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
    }
    return a.value
}

@Composable
fun NumField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true, label = { Text(label, color = p.dim) },
        textStyle = TextStyle(color = p.ink, fontSize = 18.sp), colors = fieldColors(),
        shape = RoundedCornerShape(16.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
fun TxtField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, lines: Int = 1) {
    val p = LocalPal.current
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = lines == 1, minLines = lines,
        label = { Text(label, color = p.dim) }, textStyle = TextStyle(color = p.ink, fontSize = 18.sp),
        colors = fieldColors(), shape = RoundedCornerShape(16.dp), modifier = modifier
    )
}

@Composable
fun BigResult(label: String, value: String, size: Int = 34) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(p.brand).padding(20.dp)) {
        Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = size.sp, fontWeight = FontWeight.Light, maxLines = 2)
    }
}

@Composable
fun Tiles(items: List<Pair<String, String>>, per: Int = 2) {
    items.chunked(per).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { StatTile(it.first, it.second, Modifier.weight(1f)) }
            repeat(per - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
fun Donut(frac: Float, modifier: Modifier) {
    val p = LocalPal.current
    val f by animateFloatAsState(frac, tween(700), label = "donut")
    Canvas(modifier) {
        val sw = 22.dp.toPx()
        val tl = Offset(sw / 2, sw / 2)
        val sz = Size(size.width - sw, size.height - sw)
        drawArc(DOWN, -90f + 360f * f, 360f * (1f - f), false, tl, sz, style = Stroke(sw))
        drawArc(p.brand, -90f, 360f * f, false, tl, sz, style = Stroke(sw))
    }
}

@Composable
fun GrowthChart(vals: List<Double>, key: Any) {
    val p = LocalPal.current
    val prog = remember { Animatable(0f) }
    LaunchedEffect(key) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
    }
    Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(22.dp)).background(p.ink.copy(alpha = 0.05f))) {
        LineChart(vals, UP, Modifier.fillMaxSize(), prog.value)
    }
}

// ---------------------------------------------------------------- tools hub
@Composable
fun ToolsTab(modifier: Modifier) {
    val names = listOf("GST", "EMI", "SIP", "Interest", "Discount", "Split", "Words", "Dates", "Programmer", "Stats", "Equation", "Notepad")
    var sel by remember { mutableStateOf(0) }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> Chip(n, sel == i) { sel = i } }
        }
        Spacer(Modifier.height(10.dp))
        AnimatedContent(
            targetState = sel, modifier = Modifier.weight(1f).fillMaxWidth(),
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(120)) }, label = "tool"
        ) { i ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (i) {
                    0 -> GstTool()
                    1 -> EmiTool()
                    2 -> SipTool()
                    3 -> InterestTool()
                    4 -> DiscountTool()
                    5 -> SplitTool()
                    6 -> WordsTool()
                    7 -> DateTool()
                    8 -> ProgTool()
                    9 -> StatsTool()
                    10 -> EqTool()
                    else -> PadTool()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun GstTool() {
    var amt by remember { mutableStateOf("1000") }
    var rate by remember { mutableStateOf(18) }
    var add by remember { mutableStateOf(true) }
    val a = num(amt)
    val gst = if (add) a * rate / 100.0 else a - a / (1 + rate / 100.0)
    val net = if (add) a else a - gst
    val total = net + gst
    val r = rememberRoll(total)
    NumField("Amount", amt, { amt = it }, Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Add GST", add) { add = true }
        Chip("Remove GST", !add) { add = false }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (x in listOf(3, 5, 12, 18, 28)) Chip("$x%", rate == x) { rate = x }
    }
    BigResult("Total amount", money(total * r))
    Tiles(listOf("Net price" to money(net * r), "GST" to money(gst * r), "CGST" to money(gst / 2 * r), "SGST" to money(gst / 2 * r)))
}

@Composable
fun EmiTool() {
    val p = LocalPal.current
    var pr by remember { mutableStateOf("500000") }
    var rt by remember { mutableStateOf("8.5") }
    var yr by remember { mutableStateOf("5") }
    var inMonths by remember { mutableStateOf(false) }
    val n = Math.round(if (inMonths) num(yr) else num(yr) * 12).toInt()
    val i = num(rt) / 1200.0
    val pw = Math.pow(1 + i, n.toDouble())
    val emi = if (n <= 0) 0.0 else if (i == 0.0) num(pr) / n else num(pr) * i * pw / (pw - 1)
    val total = emi * n
    val interest = total - num(pr)
    val r = rememberRoll(emi)
    NumField("Loan amount", pr, { pr = it }, Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        NumField("Interest % per year", rt, { rt = it }, Modifier.weight(1f))
        NumField(if (inMonths) "Months" else "Years", yr, { yr = it }, Modifier.weight(1f))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Years", !inMonths) { inMonths = false }
        Chip("Months", inMonths) { inMonths = true }
    }
    BigResult("Monthly EMI", money(emi * r))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Donut(if (total > 0) (num(pr) / total).toFloat() else 0f, Modifier.size(120.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Principal  " + money(num(pr)), color = p.ink, fontSize = 14.sp)
            Text("Interest  " + money(interest), color = DOWN, fontSize = 14.sp)
        }
    }
    Tiles(listOf("Total payable" to money(total), "Total interest" to money(interest)))
}

private fun fvSip(m: Double, i: Double, n: Int): Double =
    if (i == 0.0) m * n else m * ((Math.pow(1 + i, n.toDouble()) - 1) / i) * (1 + i)

@Composable
fun SipTool() {
    var amt by remember { mutableStateOf("5000") }
    var rt by remember { mutableStateOf("12") }
    var yr by remember { mutableStateOf("10") }
    val y = num(yr).toInt().coerceIn(1, 60)
    val i = num(rt) / 1200.0
    val fv = fvSip(num(amt), i, y * 12)
    val invested = num(amt) * y * 12
    val r = rememberRoll(fv)
    NumField("Monthly investment", amt, { amt = it }, Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        NumField("Return % per year", rt, { rt = it }, Modifier.weight(1f))
        NumField("Years", yr, { yr = it }, Modifier.weight(1f))
    }
    BigResult("Future value", money(fv * r))
    GrowthChart((0..y).map { fvSip(num(amt), i, it * 12) }, amt + rt + yr)
    Tiles(listOf("Invested" to money(invested), "Gains" to money(fv - invested)))
}

@Composable
fun InterestTool() {
    var pr by remember { mutableStateOf("100000") }
    var rt by remember { mutableStateOf("7") }
    var yr by remember { mutableStateOf("5") }
    var f by remember { mutableStateOf(4) }
    val y = num(yr).toInt().coerceIn(1, 60)
    fun mat(t: Int): Double = num(pr) * Math.pow(1 + num(rt) / 100.0 / f, (f * t).toDouble())
    val m = mat(y)
    val r = rememberRoll(m)
    NumField("Principal", pr, { pr = it }, Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        NumField("Rate % per year", rt, { rt = it }, Modifier.weight(1f))
        NumField("Years", yr, { yr = it }, Modifier.weight(1f))
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Yearly" to 1, "Half-yearly" to 2, "Quarterly" to 4, "Monthly" to 12).forEach { (n, v) -> Chip(n, f == v) { f = v } }
    }
    BigResult("Maturity amount", money(m * r))
    GrowthChart((0..y).map { mat(it) }, pr + rt + yr + f)
    Tiles(listOf("Invested" to money(num(pr)), "Interest earned" to money(m - num(pr))))
}

@Composable
fun DiscountTool() {
    var price by remember { mutableStateOf("2999") }
    var off by remember { mutableStateOf("30") }
    var extra by remember { mutableStateOf("10") }
    val fin = num(price) * (1 - num(off) / 100.0) * (1 - num(extra) / 100.0)
    val r = rememberRoll(fin)
    NumField("Original price", price, { price = it }, Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        NumField("Discount %", off, { off = it }, Modifier.weight(1f))
        NumField("Extra off %", extra, { extra = it }, Modifier.weight(1f))
    }
    BigResult("You pay", money(fin * r))
    Tiles(listOf("You save" to money(num(price) - fin), "Total off" to String.format(Locale.US, "%.1f%%", if (num(price) > 0) (1 - fin / num(price)) * 100 else 0.0)))
}

@Composable
fun SplitTool() {
    var bill by remember { mutableStateOf("2400") }
    var tip by remember { mutableStateOf(10) }
    var ppl by remember { mutableStateOf("4") }
    val tipAmt = num(bill) * tip / 100.0
    val total = num(bill) + tipAmt
    val n = if (num(ppl) < 1) 1.0 else Math.floor(num(ppl))
    val r = rememberRoll(total / n)
    NumField("Bill amount", bill, { bill = it }, Modifier.fillMaxWidth())
    NumField("People", ppl, { ppl = it }, Modifier.fillMaxWidth())
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (x in listOf(0, 5, 10, 15, 20)) Chip("Tip $x%", tip == x) { tip = x }
    }
    BigResult("Each person pays", money(total / n * r))
    Tiles(listOf("Tip" to money(tipAmt), "Total bill" to money(total)))
}

private val ONES = listOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
private val TENS = listOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
private fun w100(n: Int): String = if (n < 20) ONES[n] else TENS[n / 10] + (if (n % 10 != 0) "-" + ONES[n % 10] else "")
private fun w1000(n: Int): String {
    val h = n / 100
    val r = n % 100
    return (if (h > 0) ONES[h] + " hundred" + (if (r > 0) " " else "") else "") + (if (r > 0) w100(r) else "")
}

fun words(n: Long, indian: Boolean): String {
    if (n == 0L) return "zero"
    val parts = ArrayList<String>()
    var x = n
    if (indian) {
        val cr = x / 10000000L
        x %= 10000000L
        if (cr > 0) parts.add(words(cr, true) + " crore")
        val lk = (x / 100000L).toInt()
        x %= 100000L
        if (lk > 0) parts.add(w100(lk) + " lakh")
        val th = (x / 1000L).toInt()
        x %= 1000L
        if (th > 0) parts.add(w100(th) + " thousand")
    } else {
        val sc = listOf(1_000_000_000_000L to "trillion", 1_000_000_000L to "billion", 1_000_000L to "million", 1000L to "thousand")
        for ((v, nm) in sc) {
            val q = x / v
            if (q > 0) { parts.add(w1000(q.toInt()) + " " + nm); x %= v }
        }
    }
    if (x > 0) parts.add(w1000(x.toInt()))
    return parts.joinToString(" ")
}

@Composable
fun WordsTool() {
    val p = LocalPal.current
    var t by remember { mutableStateOf("1234567") }
    val s = t.replace(",", "").trim()
    val d = s.toDoubleOrNull()
    NumField("Number", t, { t = it }, Modifier.fillMaxWidth())
    if (d == null || d < 0 || d >= 1e15) {
        Text("Enter a number below 1,000 trillion.", color = p.dim)
    } else {
        val frac = if (s.contains('.')) " point " + s.substringAfter('.').filter { it.isDigit() }.map { ONES[it.digitToInt()] }.joinToString(" ") else ""
        val whole = d.toLong()
        BigResult("Indian system", (words(whole, true) + frac).replaceFirstChar { it.uppercase() }, 22)
        BigResult("International system", (words(whole, false) + frac).replaceFirstChar { it.uppercase() }, 22)
    }
}

@Composable
fun DateBox(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.bounce(onClick).clip(shape).background(p.ink.copy(alpha = 0.08f))
            .border(1.dp, p.ink.copy(alpha = 0.1f), shape).padding(14.dp)
    ) {
        Text(label, color = p.dim, fontSize = 12.sp)
        Text(value, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun DateTool() {
    val ctx = LocalContext.current
    var a by remember { mutableStateOf(LocalDate.now()) }
    var b by remember { mutableStateOf(LocalDate.now().plusDays(30)) }
    var addTxt by remember { mutableStateOf("100") }
    var minus by remember { mutableStateOf(false) }
    val f = DateTimeFormatter.ofPattern("EEE, d MMM yyyy")
    fun pick(init: LocalDate, cb: (LocalDate) -> Unit) {
        DatePickerDialog(ctx, { _, y, m, d -> cb(LocalDate.of(y, m + 1, d)) }, init.year, init.monthValue - 1, init.dayOfMonth).show()
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        DateBox("From", a.format(f), Modifier.weight(1f)) { pick(a) { a = it } }
        DateBox("To", b.format(f), Modifier.weight(1f)) { pick(b) { b = it } }
    }
    val lo = if (a.isBefore(b)) a else b
    val hi = if (a.isBefore(b)) b else a
    val per = Period.between(lo, hi)
    val days = ChronoUnit.DAYS.between(lo, hi)
    BigResult("Difference", per.years.toString() + " years  " + per.months + " months  " + per.days + " days", 24)
    Tiles(listOf("Total days" to pretty(days.toString()), "Weeks" to (days / 7).toString() + " w " + (days % 7) + " d"))
    Label("ADD OR SUBTRACT DAYS")
    NumField("Days", addTxt, { addTxt = it }, Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Add", !minus) { minus = false }
        Chip("Subtract", minus) { minus = true }
    }
    val dn = num(addTxt).toLong()
    BigResult("Result date", (if (minus) a.minusDays(dn) else a.plusDays(dn)).format(f), 24)
}

@Composable
fun BaseRows(v: Long) {
    val p = LocalPal.current
    val bin = java.lang.Long.toBinaryString(v)
    val rows = listOf(
        "DEC" to v.toString(), "HEX" to java.lang.Long.toHexString(v).uppercase(), "OCT" to java.lang.Long.toOctalString(v),
        "BIN" to bin.padStart((bin.length + 3) / 4 * 4, '0').chunked(4).joinToString(" ")
    )
    for ((n, s) in rows) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.ink.copy(alpha = 0.07f)).padding(12.dp)) {
            Text(n, color = p.dim, fontSize = 13.sp, modifier = Modifier.width(48.dp))
            Text(s, color = p.ink, fontSize = 15.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun ProgTool() {
    val p = LocalPal.current
    var txt by remember { mutableStateOf("255") }
    var base by remember { mutableStateOf(10) }
    var b2 by remember { mutableStateOf("15") }
    var op by remember { mutableStateOf(0) }
    val ops = listOf("AND", "OR", "XOR", "<<", ">>", "NOT")
    val a = txt.trim().toLongOrNull(base)
    val b = b2.trim().toLongOrNull(base)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("DEC" to 10, "HEX" to 16, "OCT" to 8, "BIN" to 2).forEach { (n, bs) -> Chip(n, base == bs) { base = bs } }
    }
    TxtField("Value (base " + base + ")", txt, { txt = it }, Modifier.fillMaxWidth())
    if (a == null) Text("Not valid in this base.", color = p.dim) else BaseRows(a)
    Label("BITWISE")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ops.forEachIndexed { i, n -> Chip(n, op == i) { op = i } }
    }
    if (op != 5) TxtField("Second value", b2, { b2 = it }, Modifier.fillMaxWidth())
    val res: Long? = if (a == null) null else when (op) {
        0 -> if (b == null) null else a and b
        1 -> if (b == null) null else a or b
        2 -> if (b == null) null else a xor b
        3 -> if (b == null) null else a shl b.toInt()
        4 -> if (b == null) null else a shr b.toInt()
        else -> a.inv()
    }
    if (res != null) {
        Label("RESULT")
        BaseRows(res)
    }
}

@Composable
fun StatsTool() {
    val p = LocalPal.current
    var t by remember { mutableStateOf("12, 15, 20, 20, 33, 41") }
    val xs = Regex("-?\\d+(?:\\.\\d+)?").findAll(t).map { it.value.toDouble() }.toList()
    TxtField("Numbers (spaces or commas)", t, { t = it }, Modifier.fillMaxWidth(), 3)
    if (xs.isEmpty()) {
        Text("Type some numbers above.", color = p.dim)
    } else {
        val n = xs.size
        val sum = xs.sum()
        val mean = sum / n
        val sorted = xs.sorted()
        val median = if (n % 2 == 1) sorted[n / 2] else (sorted[n / 2 - 1] + sorted[n / 2]) / 2
        val counts = xs.groupingBy { it }.eachCount()
        val mx = counts.values.max()
        val mode = if (mx == 1) "none" else counts.filter { it.value == mx }.keys.sorted().joinToString(", ") { pretty(fmt(it)) }
        val pv = xs.sumOf { (it - mean) * (it - mean) } / n
        val sv = if (n > 1) xs.sumOf { (it - mean) * (it - mean) } / (n - 1) else 0.0
        fun f(v: Double) = pretty(fmt(v))
        BigResult("Mean", f(mean))
        Tiles(
            listOf(
                "Count" to n.toString(), "Sum" to f(sum), "Median" to f(median), "Mode" to mode,
                "Min" to f(sorted.first()), "Max" to f(sorted.last()), "Range" to f(sorted.last() - sorted.first()),
                "Std dev (pop)" to f(Math.sqrt(pv)), "Std dev (sample)" to f(Math.sqrt(sv)), "Variance" to f(pv)
            )
        )
    }
}

@Composable
fun EqTool() {
    val p = LocalPal.current
    var mode by remember { mutableStateOf(0) }
    var a by remember { mutableStateOf("1") }
    var b by remember { mutableStateOf("-3") }
    var c by remember { mutableStateOf("2") }
    var d by remember { mutableStateOf("2") }
    var e by remember { mutableStateOf("1") }
    var g by remember { mutableStateOf("8") }
    fun f(v: Double) = pretty(fmt(v))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Quadratic", mode == 0) { mode = 0 }
        Chip("Two unknowns", mode == 1) { mode = 1 }
    }
    if (mode == 0) {
        Text("a x^2 + b x + c = 0", color = p.dim, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NumField("a", a, { a = it }, Modifier.weight(1f))
            NumField("b", b, { b = it }, Modifier.weight(1f))
            NumField("c", c, { c = it }, Modifier.weight(1f))
        }
        val qa = num(a)
        val qb = num(b)
        val qc = num(c)
        val disc = qb * qb - 4 * qa * qc
        if (qa == 0.0) {
            if (qb == 0.0) BigResult("Solution", "Not an equation", 24)
            else BigResult("Linear: x =", f(-qc / qb), 30)
        } else if (disc >= 0) {
            val s = Math.sqrt(disc)
            BigResult("Roots", "x = " + f((-qb + s) / (2 * qa)) + "   or   " + f((-qb - s) / (2 * qa)), 24)
        } else {
            val re = -qb / (2 * qa)
            val im = Math.sqrt(-disc) / (2 * Math.abs(qa))
            BigResult("Complex roots", f(re) + " ± " + f(im) + " i", 24)
        }
        Tiles(listOf("Discriminant" to f(disc), "Vertex x" to (if (qa == 0.0) "-" else f(-qb / (2 * qa)))))
    } else {
        Text("a1 x + b1 y = c1   and   a2 x + b2 y = c2", color = p.dim, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NumField("a1", a, { a = it }, Modifier.weight(1f))
            NumField("b1", b, { b = it }, Modifier.weight(1f))
            NumField("c1", c, { c = it }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NumField("a2", d, { d = it }, Modifier.weight(1f))
            NumField("b2", e, { e = it }, Modifier.weight(1f))
            NumField("c2", g, { g = it }, Modifier.weight(1f))
        }
        val det = num(a) * num(e) - num(d) * num(b)
        if (det == 0.0) BigResult("Solution", "No single solution", 24)
        else BigResult("Solution", "x = " + f((num(c) * num(e) - num(g) * num(b)) / det) + "   y = " + f((num(a) * num(g) - num(d) * num(c)) / det), 24)
    }
}

@Composable
fun PadTool() {
    val ctx = LocalContext.current
    var t by remember { mutableStateOf(Cfg.getStr("pad")) }
    val re = Regex("-?\\d[\\d,]*(?:\\.\\d+)?")
    val vals = t.lines().mapNotNull { ln -> re.findAll(ln).lastOrNull()?.value?.replace(",", "")?.toDoubleOrNull() }
    val total = vals.sum()
    val r = rememberRoll(total)
    TxtField("Type lines like: rent 12000", t, { t = it; Cfg.putStr("pad", it) }, Modifier.fillMaxWidth(), 7)
    BigResult("Total", pretty(String.format(Locale.US, "%.2f", total * r)))
    Tiles(listOf("Items" to vals.size.toString(), "Average" to (if (vals.isEmpty()) "0" else pretty(fmt(total / vals.size)))))
    Chip("Share as text", false) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, t + "\n\nTotal: " + fmt(total))
        ctx.startActivity(Intent.createChooser(i, "Share"))
    }
}

// ---------------------------------------------------------------- portfolio, gold, markets hub
class Holding(val sym: String, val qty: Double, val buy: Double)

object Port {
    val list = mutableStateListOf<Holding>()

    fun load() {
        list.clear()
        for (e in Cfg.getStr("port").split(";")) {
            val x = e.split("|")
            if (x.size == 3) {
                val q = x[1].toDoubleOrNull()
                val b = x[2].toDoubleOrNull()
                if (q != null && b != null) list.add(Holding(x[0], q, b))
            }
        }
    }

    fun save() { Cfg.putStr("port", list.joinToString(";") { it.sym + "|" + it.qty + "|" + it.buy }) }
}

@Composable
fun Portfolio(modifier: Modifier) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val prices = remember { mutableStateMapOf<String, Double>() }
    var adding by remember { mutableStateOf(false) }
    fun refresh() {
        for (h in Port.list.toList()) scope.launch {
            val q = Net.quote(h.sym, "5d", "1d", true)
            if (q != null) prices[h.sym] = q.price
        }
    }
    LaunchedEffect(Unit) { refresh() }
    var invested = 0.0
    var current = 0.0
    for (h in Port.list) {
        invested += h.qty * h.buy
        current += h.qty * (prices[h.sym] ?: h.buy)
    }
    val pl = current - invested
    val r = rememberRoll(current)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Portfolio", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconBtn(Icons.Rounded.Refresh, false) { refresh() }
            Spacer(Modifier.width(8.dp))
            IconBtn(Icons.Rounded.Add, false) { adding = true }
        }
        BigResult("Current value", px(current * r))
        Tiles(
            listOf(
                "Invested" to px(invested), "Profit / loss" to (px(pl) + if (invested > 0) String.format(Locale.US, "  (%+.1f%%)", pl / invested * 100) else "")
            )
        )
        Text("Tap + to add holdings. Long-press to remove. Prices are in each asset's own currency.", color = p.dim, fontSize = 12.sp)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(Port.list.toList()) { idx, h ->
                val now = prices[h.sym]
                val gain = if (now != null) (now - h.buy) * h.qty else 0.0
                val shape = RoundedCornerShape(20.dp)
                Row(
                    Modifier.fillMaxWidth().clip(shape).background(p.ink.copy(alpha = 0.07f)).border(1.dp, p.ink.copy(alpha = 0.08f), shape)
                        .pointerInput(h) { detectTapGestures(onLongPress = { Port.list.remove(h); Port.save() }) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(h.sym, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(pretty(h.qty.toString()) + " at " + px(h.buy), color = p.dim, fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (now != null) px(now) else "...", color = p.ink, fontSize = 16.sp)
                        Text(if (now != null) px(gain) else "", color = if (gain >= 0) UP else DOWN, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
    if (adding) {
        var sym by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        var buy by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false }, containerColor = p.surf,
            title = { Text("Add holding", color = p.ink) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TxtField("Symbol (AAPL, INFY.NS)", sym, { sym = it })
                    NumField("Quantity", qty, { qty = it })
                    NumField("Buy price", buy, { buy = it })
                }
            },
            confirmButton = {
                Text(
                    "Add", color = p.a2, fontWeight = FontWeight.Bold,
                    modifier = Modifier.bounce {
                        if (sym.isNotBlank() && num(qty) > 0) {
                            Port.list.add(Holding(sym.trim().uppercase(), num(qty), num(buy)))
                            Port.save()
                            adding = false
                            refresh()
                        }
                    }.padding(12.dp)
                )
            },
            dismissButton = { Text("Cancel", color = p.dim, modifier = Modifier.bounce { adding = false }.padding(12.dp)) }
        )
    }
}

@Composable
fun Gold(modifier: Modifier) {
    val p = LocalPal.current
    var g by remember { mutableStateOf<Quote?>(null) }
    var s by remember { mutableStateOf<Quote?>(null) }
    var fx by remember { mutableStateOf<Quote?>(null) }
    var failed by remember { mutableStateOf(false) }
    var retry by remember { mutableStateOf(0) }
    LaunchedEffect(retry) {
        failed = false
        g = Net.quote("GC=F", "1mo", "1d", true)
        s = Net.quote("SI=F", "1mo", "1d", true)
        fx = Net.quote("USDINR=X", "5d", "1d", true)
        failed = g == null || s == null || fx == null
    }
    val gq = g
    val sq = s
    val fq = fx
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Gold and silver in INR", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (gq != null && sq != null && fq != null) {
            val oz = 31.1035
            val g24 = gq.price * fq.price / oz * 10
            val roll = rememberRoll(g24)
            BigResult("Gold 24K per 10 g", money(g24 * roll))
            Tiles(
                listOf(
                    "22K per 10 g" to money(g24 * 0.9167), "18K per 10 g" to money(g24 * 0.75),
                    "Silver per kg" to money(sq.price * fq.price / oz * 1000), "Silver per 10 g" to money(sq.price * fq.price / oz * 10),
                    "Gold USD/oz" to px(gq.price), "USD to INR" to px(fq.price)
                )
            )
            GrowthChart(gq.closes, "gold")
            Text("Indicative: international price converted to INR. Indian shop prices include import duty and GST, so they will be higher.", color = p.dim, fontSize = 12.sp)
        } else if (failed) {
            Text("Could not load prices. Check your internet.", color = p.dim)
            Chip("Try again", false) { retry++ }
        } else {
            Text("Loading...", color = p.dim)
        }
    }
}

@Composable
fun Markets(modifier: Modifier) {
    var sub by remember { mutableStateOf(0) }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Watchlist", "Portfolio", "Gold and Silver").forEachIndexed { i, n -> Chip(n, sub == i) { sub = i } }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (sub) {
                0 -> Watchlist(Modifier.fillMaxSize())
                1 -> Portfolio(Modifier.fillMaxSize())
                else -> Gold(Modifier.fillMaxSize())
            }
        }
    }
}
