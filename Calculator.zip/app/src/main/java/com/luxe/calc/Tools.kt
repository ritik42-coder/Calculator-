package com.luxe.calc

import android.app.DatePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.Period
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt

val UP = Color(0xFF2ED47A)
val DOWN = Color(0xFFFF5C6C)

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = LocalPal.current.a1, unfocusedBorderColor = LocalPal.current.dim,
    cursorColor = LocalPal.current.a2
)

@Composable
fun StatTile(label: String, value: String, modifier: Modifier) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape).background(p.ink.copy(alpha = 0.07f)).border(1.dp, p.ink.copy(alpha = 0.08f), shape).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = p.ink, fontSize = 20.sp, fontWeight = FontWeight.Light, maxLines = 1)
        Text(label, color = p.dim, fontSize = 12.sp)
    }
}

// ---------------------------------------------------------------- charts + markets
@Composable
fun LineChart(v: List<Double>, color: Color, modifier: Modifier, progress: Float = 1f, sel: Int? = null) {
    Canvas(modifier) {
        if (v.size < 2) return@Canvas
        val mn = v.minOrNull() ?: 0.0
        val mx = v.maxOrNull() ?: 1.0
        val rng = if (mx - mn > 0.0) mx - mn else 1.0
        val n = (v.size * progress).toInt().coerceIn(2, v.size)
        val path = Path()
        val fill = Path()
        var lx = 0f
        for (i in 0 until n) {
            val x = size.width * i / (v.size - 1)
            val y = size.height * (0.95f - 0.9f * ((v[i] - mn) / rng).toFloat())
            if (i == 0) {
                path.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y)
            } else {
                path.lineTo(x, y); fill.lineTo(x, y)
            }
            lx = x
        }
        fill.lineTo(lx, size.height)
        fill.close()
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(path, color, style = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        if (sel != null && sel >= 0 && sel < v.size) {
            val x = size.width * sel / (v.size - 1)
            val y = size.height * (0.95f - 0.9f * ((v[sel] - mn) / rng).toFloat())
            drawLine(color.copy(alpha = 0.6f), Offset(x, 0f), Offset(x, size.height), 2f)
            drawCircle(Color.White, 9f, Offset(x, y))
            drawCircle(color, 6f, Offset(x, y))
        }
    }
}

private fun idxAt(x: Float, w: Int, n: Int): Int = if (n < 2 || w == 0) 0 else (x / w * (n - 1)).roundToInt().coerceIn(0, n - 1)

private fun tlabel(t: Long, intraday: Boolean): String {
    val z = Instant.ofEpochSecond(t).atZone(ZoneId.systemDefault())
    return z.format(DateTimeFormatter.ofPattern(if (intraday) "d MMM, HH:mm" else "d MMM yyyy"))
}

@Composable
fun Markets(modifier: Modifier) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val quotes = remember { mutableStateMapOf<String, Quote>() }
    var sel by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(0) }
    fun load(s: String) {
        scope.launch {
            busy++
            val q = Net.quote(s, "5d", "1d", true)
            if (q != null) quotes[s] = q
            busy--
        }
    }
    fun refresh() { for (s in Watch.list.toList()) load(s) }
    LaunchedEffect(Unit) { refresh() }
    val cur = sel
    if (cur != null) {
        QuoteDetail(cur, { sel = null }, modifier)
    } else {
        Column(modifier) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Markets", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconBtn(Icons.Rounded.Refresh, busy > 0) { refresh() }
                Spacer(Modifier.width(8.dp))
                IconBtn(Icons.Rounded.Add, false) { adding = true }
            }
            Text("Live prices. Tap for the chart, long-press to remove.", color = p.dim, fontSize = 12.sp)
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(Watch.list.toList()) { i, s ->
                    QuoteRow(s, quotes[s], i, { sel = s }, { Watch.remove(s) })
                }
            }
        }
    }
    if (adding) {
        AddDialog({ adding = false }) { t ->
            Watch.add(t)
            load(t.trim().uppercase())
            adding = false
        }
    }
}

@Composable
fun QuoteRow(sym: String, q: Quote?, i: Int, onTap: () -> Unit, onLong: () -> Unit) {
    val p = LocalPal.current
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(i * 50L)
        a.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
    }
    val shape = RoundedCornerShape(20.dp)
    val col = if ((q?.chg ?: 0.0) >= 0) UP else DOWN
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationX = (1f - a.value) * 60f }
            .clip(shape).background(Brush.verticalGradient(listOf(p.ink.copy(alpha = 0.10f), p.ink.copy(alpha = 0.04f))))
            .border(1.dp, p.ink.copy(alpha = 0.1f), shape)
            .pointerInput(sym) { detectTapGestures(onTap = { onTap() }, onLongPress = { onLong() }) }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(sym, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(q?.name ?: "Loading...", color = p.dim, fontSize = 12.sp, maxLines = 1)
        }
        if (q != null) {
            LineChart(q.closes, col, Modifier.width(80.dp).height(34.dp))
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(px(q.price), color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(String.format(Locale.US, "%+.2f%%", q.pct), color = col, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun QuoteDetail(sym: String, onBack: () -> Unit, modifier: Modifier) {
    val p = LocalPal.current
    val names = listOf("1D", "5D", "1M", "6M", "1Y")
    val spec = listOf("1d" to "5m", "5d" to "30m", "1mo" to "1d", "6mo" to "1d", "1y" to "1wk")
    var ri by remember { mutableStateOf(2) }
    var q by remember { mutableStateOf<Quote?>(null) }
    var failed by remember { mutableStateOf(false) }
    var selIdx by remember { mutableStateOf<Int?>(null) }
    var retry by remember { mutableStateOf(0) }
    val prog = remember { Animatable(0f) }
    BackHandler(true) { onBack() }
    LaunchedEffect(sym, ri, retry) {
        q = null
        failed = false
        selIdx = null
        prog.snapTo(0f)
        val got = Net.quote(sym, spec[ri].first, spec[ri].second, false)
        q = got
        failed = got == null
        if (got != null) prog.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
    }
    val cq = q
    val col = if ((cq?.chg ?: 0.0) >= 0) UP else DOWN
    val shape = RoundedCornerShape(26.dp)
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Rounded.ArrowBack, false, onBack)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(sym, color = p.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(cq?.name ?: "", color = p.dim, fontSize = 12.sp, maxLines = 1)
            }
        }
        if (cq != null) {
            val i = selIdx
            val price = if (i != null) cq.closes[i] else cq.price
            val chg = price - cq.prev
            val pct = if (cq.prev != 0.0) chg / cq.prev * 100.0 else 0.0
            Text(px(price) + " " + cq.cur, color = p.ink, fontSize = 36.sp, fontWeight = FontWeight.Light)
            Text(
                String.format(Locale.US, "%+.2f  (%+.2f%%)", chg, pct) +
                    (if (i != null && i < cq.times.size) "   " + tlabel(cq.times[i], ri < 2) else ""),
                color = col, fontSize = 15.sp, fontWeight = FontWeight.Medium
            )
            Box(
                Modifier.fillMaxWidth().height(250.dp).clip(shape).background(p.ink.copy(alpha = 0.05f))
                    .border(1.dp, p.ink.copy(alpha = 0.08f), shape)
                    .pointerInput(cq) {
                        detectDragGestures(
                            onDragStart = { o -> selIdx = idxAt(o.x, size.width, cq.closes.size) },
                            onDrag = { c, _ -> selIdx = idxAt(c.position.x, size.width, cq.closes.size) },
                            onDragEnd = { selIdx = null },
                            onDragCancel = { selIdx = null }
                        )
                    }
            ) { LineChart(cq.closes, col, Modifier.fillMaxSize(), prog.value, selIdx) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("High", px(cq.closes.maxOrNull() ?: 0.0), Modifier.weight(1f))
                StatTile("Low", px(cq.closes.minOrNull() ?: 0.0), Modifier.weight(1f))
                StatTile("Period", String.format(Locale.US, "%+.1f%%", (cq.price - cq.closes.first()) / cq.closes.first() * 100.0), Modifier.weight(1f))
            }
        } else if (failed) {
            Text("Could not load this symbol. Check your internet or the symbol name.", color = p.dim, fontSize = 14.sp)
            Chip("Try again", false) { retry++ }
        } else {
            Text("Loading...", color = p.dim, fontSize = 16.sp)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { k, n -> Chip(n, ri == k) { ri = k } }
        }
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    val p = LocalPal.current
    var t by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = p.surf,
        title = { Text("Add symbol", color = p.ink) },
        text = {
            Column {
                Text("Examples: INFY.NS, AAPL, BTC-USD, ^GSPC", color = p.dim, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = t, onValueChange = { t = it }, singleLine = true,
                    textStyle = TextStyle(color = p.ink, fontSize = 18.sp), colors = fieldColors()
                )
            }
        },
        confirmButton = {
            Text("Add", color = p.a2, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { if (t.isNotBlank()) onAdd(t) }.padding(12.dp))
        },
        dismissButton = { Text("Cancel", color = p.dim, modifier = Modifier.clickable { onDismiss() }.padding(12.dp)) }
    )
}

// ---------------------------------------------------------------- graph
private fun niceStep(raw: Float): Float {
    val b = 10f.pow(floor(log10(raw)))
    val m = raw / b
    return b * (if (m < 1.5f) 1f else if (m < 3.5f) 2f else if (m < 7.5f) 5f else 10f)
}

@Composable
fun GraphTab(modifier: Modifier) {
    val p = LocalPal.current
    var f by remember { mutableStateOf("sin(x)") }
    var scale by remember { mutableStateOf(48f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    val prog = remember { Animatable(0f) }
    LaunchedEffect(f) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
    }
    val ok = remember(f) {
        try { Engine.xv = 1.0; Engine.calc(f); true } catch (e: Exception) { false }
    }
    val shape = RoundedCornerShape(24.dp)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = f, onValueChange = { f = it }, singleLine = true, label = { Text("y =", color = p.dim) },
            textStyle = TextStyle(color = p.ink, fontSize = 18.sp), colors = fieldColors(),
            shape = RoundedCornerShape(Cfg.radius.dp), modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (s in listOf("sin(x)", "cos(x)", "tan(x)", "x^2", "x^3", "√(x)", "ln(x)", "1÷x", "2^x")) Chip(s, f == s) { f = s }
            Chip("Reset view", false) { scale = 48f; off = Offset.Zero }
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(shape).background(p.ink.copy(alpha = 0.05f))
                .border(1.dp, p.ink.copy(alpha = 0.08f), shape)
        ) {
            Canvas(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(6f, 600f)
                        off += pan
                    }
                }
            ) {
                val w = size.width
                val h = size.height
                val cx = w / 2f + off.x
                val cy = h / 2f + off.y
                val step = niceStep(60f / scale)
                val grid = p.ink.copy(alpha = 0.07f)
                val x0 = floor(-cx / scale / step).toInt() - 1
                val x1 = ceil((w - cx) / scale / step).toInt() + 1
                for (i in x0..x1) {
                    val sx = cx + i * step * scale
                    drawLine(grid, Offset(sx, 0f), Offset(sx, h), 1f)
                }
                val y0 = floor((cy - h) / scale / step).toInt() - 1
                val y1 = ceil(cy / scale / step).toInt() + 1
                for (j in y0..y1) {
                    val sy = cy - j * step * scale
                    drawLine(grid, Offset(0f, sy), Offset(w, sy), 1f)
                }
                drawLine(p.ink.copy(alpha = 0.45f), Offset(0f, cy), Offset(w, cy), 2.5f)
                drawLine(p.ink.copy(alpha = 0.45f), Offset(cx, 0f), Offset(cx, h), 2.5f)
                if (ok) {
                    val path = Path()
                    var pen = false
                    var py = 0f
                    var pxv = 0f
                    val lim = w * prog.value
                    while (pxv <= lim) {
                        Engine.xv = ((pxv - cx) / scale).toDouble()
                        val yv = try { Engine.calc(f) } catch (e: Exception) { Double.NaN }
                        val sy = (cy - yv * scale).toFloat()
                        if (yv.isFinite() && abs(sy) < 20000f) {
                            if (pen && abs(sy - py) < h * 1.5f) path.lineTo(pxv, sy) else path.moveTo(pxv, sy)
                            pen = true
                            py = sy
                        } else {
                            pen = false
                        }
                        pxv += 2f
                    }
                    drawPath(path, p.brand, style = Stroke(width = 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            if (!ok) Text("Not a valid expression", color = p.dim, modifier = Modifier.align(Alignment.Center))
            Text("Drag to move, pinch to zoom", color = p.dim, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp))
        }
    }
}

// ---------------------------------------------------------------- age
@Composable
fun AgeTab(modifier: Modifier) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var dob by remember { mutableStateOf<LocalDate?>(try { LocalDate.parse(Cfg.getStr("dob")) } catch (e: Exception) { null }) }
    var on by remember { mutableStateOf(LocalDate.now()) }
    val prog = remember { Animatable(0f) }
    LaunchedEffect(dob, on) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))
    }
    fun pick(init: LocalDate, cb: (LocalDate) -> Unit) {
        DatePickerDialog(ctx, { _, y, m, d -> cb(LocalDate.of(y, m + 1, d)) }, init.year, init.monthValue - 1, init.dayOfMonth).show()
    }
    val fmtD = DateTimeFormatter.ofPattern("d MMM yyyy")
    val shape = RoundedCornerShape(22.dp)
    val d = dob
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Age calculator", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(
                Modifier.weight(1f).bounce { pick(d ?: LocalDate.of(2000, 1, 1)) { dob = it; Cfg.putStr("dob", it.toString()) } }
                    .clip(shape).background(p.brand).padding(14.dp)
            ) {
                Text("Date of birth", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                Text(d?.format(fmtD) ?: "Tap to pick", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
            Column(
                Modifier.weight(1f).bounce { pick(on) { on = it } }
                    .clip(shape).background(p.ink.copy(alpha = 0.08f)).border(1.dp, p.ink.copy(alpha = 0.1f), shape).padding(14.dp)
            ) {
                Text("Age on", color = p.dim, fontSize = 12.sp)
                Text(on.format(fmtD), color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (d == null || on.isBefore(d)) {
            Text(
                if (d == null) "Pick your date of birth to see your exact age, live countdowns and more."
                else "The date must be after the birth date.",
                color = p.dim, fontSize = 15.sp, modifier = Modifier.padding(top = 30.dp).fillMaxWidth(), textAlign = TextAlign.Center
            )
        } else {
            val per = Period.between(d, on)
            val days = ChronoUnit.DAYS.between(d, on)
            var nb = d.withYear(on.year)
            if (nb.isBefore(on)) nb = nb.plusYears(1)
            val toNext = ChronoUnit.DAYS.between(on, nb)
            val frac = (1f - toNext / 365f).coerceIn(0f, 1f)
            val pr = prog.value
            Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(200.dp)) {
                    val sw = 16.dp.toPx()
                    val tl = Offset(sw / 2, sw / 2)
                    val sz = Size(size.width - sw, size.height - sw)
                    drawArc(p.ink.copy(alpha = 0.1f), 0f, 360f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    drawArc(p.brand, -90f, 360f * frac * pr, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text((toNext * pr).roundToInt().toString(), color = p.ink, fontSize = 48.sp, fontWeight = FontWeight.Light)
                    Text("days to next birthday", color = p.dim, fontSize = 13.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Years", (per.years * pr).roundToInt().toString(), Modifier.weight(1f))
                StatTile("Months", (per.months * pr).roundToInt().toString(), Modifier.weight(1f))
                StatTile("Days", (per.days * pr).roundToInt().toString(), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Total months", pretty(((per.years * 12L + per.months) * pr).roundToInt().toString()), Modifier.weight(1f))
                StatTile("Total weeks", pretty((days / 7 * pr).roundToInt().toString()), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Total days", pretty((days * pr).roundToInt().toString()), Modifier.weight(1f))
                StatTile("Total hours", pretty((days * 24 * pr).toLong().toString()), Modifier.weight(1f))
            }
            Text(
                "Born on a " + d.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()) +
                    ". Next birthday on " + nb.format(fmtD) + ".",
                color = p.dim, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            )
        }
    }
}
