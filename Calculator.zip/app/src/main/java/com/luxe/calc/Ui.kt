package com.luxe.calc

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- state
class CalcState {
    var ex by mutableStateOf("")
    var res by mutableStateOf<String?>(null)
    var bad by mutableStateOf(false)
    var saved by mutableStateOf("")
    var mem by mutableStateOf(0.0)

    private fun cur(): Double? = try {
        val r = res
        val v = if (r != null && !bad) Engine.calc(r) else Engine.calc(ex)
        if (v.isFinite()) v else null
    } catch (e: Exception) { null }

    val preview: String
        get() {
            if (res != null || !ex.any { !(it.isDigit() || it == '.') }) return ""
            val v = cur() ?: return ""
            return "= " + pretty(fmt(v))
        }

    private val opEnd = Regex("[÷×−+^]$")
    private val opEnd2 = Regex("[÷×^]$")
    private val fnEnd = Regex("(asin|acos|atan|sin|cos|tan|ln|log)\\($|.$")

    fun press(v: String) {
        val isOp = v == "÷" || v == "×" || v == "−" || v == "+" || v == "^"
        val isPost = v == "%" || v == "!" || v == "^2" || v == "^(−1)"
        when (v) {
            "AC" -> { ex = ""; res = null; bad = false; return }
            "bk" -> {
                if (res != null) { res = null; if (bad) ex = "" } else ex = ex.replace(fnEnd, "")
                return
            }
            "eq" -> { evaluate(); return }
            "deg" -> { Cfg.deg = !Cfg.deg; Engine.deg = Cfg.deg; Cfg.save(); return }
            "MC", "MR", "M+", "M−" -> { memOp(v); return }
        }
        val r0 = res
        if (r0 != null) { ex = if ((isOp || isPost) && !bad) r0 else ""; res = null; bad = false }
        if (isOp) {
            if (ex.isEmpty()) { if (v != "−") return }
            else if (opEnd.containsMatchIn(ex)) { if (!(v == "−" && opEnd2.containsMatchIn(ex))) ex = ex.dropLast(1) }
            else if (ex.endsWith("(") && v != "−") return
        }
        var add = v
        if (v == ".") {
            val n = Regex("[\\d.]*$").find(ex)?.value ?: ""
            if (n.contains('.')) return
            if (n.isEmpty()) add = "0."
        }
        if (v == "par") {
            val o = ex.count { it == '(' }
            val c = ex.count { it == ')' }
            add = if (o > c && Regex("[\\d)πe%!]$").containsMatchIn(ex)) ")" else "("
        }
        if (ex.length < 60) ex += add
    }

    private fun memOp(v: String) {
        if (v == "MC") { mem = 0.0; return }
        if (v == "MR") {
            if (res != null) { ex = ""; res = null; bad = false }
            val s = fmt(mem)
            ex += if (mem < 0) "($s)" else s
            return
        }
        val q = cur() ?: return
        mem += if (v == "M+") q else -q
    }

    private fun evaluate() {
        if (res != null || ex.isEmpty()) return
        val v = try { Engine.calc(ex) } catch (e: Exception) { Double.NaN }
        saved = ex
        bad = !v.isFinite()
        val out = if (bad) (if (v.isInfinite()) "Can't divide by 0" else "Format error") else fmt(v)
        res = out
        if (!bad) Cfg.addHistory(ex, out)
    }
}

class CvState {
    var cat by mutableStateOf("Length")
    var from by mutableStateOf("m")
    var to by mutableStateOf("ft")
    var cs by mutableStateOf("1")

    fun result(): Double = convert(cat, from, to, cs.toDoubleOrNull() ?: 0.0)

    fun pick(c: String) {
        cat = c
        val d = DEFAULT_UNITS[c] ?: return
        from = d.first
        to = d.second
    }

    fun press(v: String) {
        when (v) {
            "AC" -> cs = "0"
            "bk" -> cs = if (cs.length <= 1) "0" else cs.dropLast(1).let { if (it == "-") "0" else it }
            "±" -> if (cs != "0") cs = if (cs.startsWith("-")) cs.drop(1) else "-$cs"
            "sw" -> {
                val r = fmt(result()).replace('−', '-')
                val t = from
                from = to
                to = t
                cs = if (r.contains("×")) "0" else r
            }
            "." -> if (!cs.contains('.')) cs += "."
            else -> if (cs == "0") cs = v else if (cs.length < 15) cs += v
        }
    }
}

// ---------------------------------------------------------------- small pieces
fun Modifier.bounce(onClick: () -> Unit): Modifier = composed {
    var down by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (down) 0.94f else 1f, spring(dampingRatio = 0.5f, stiffness = 600f), label = "bounce")
    val cb by rememberUpdatedState(onClick)
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .pointerInput(Unit) {
            detectTapGestures(onPress = { down = true; tryAwaitRelease(); down = false }, onTap = { cb() })
        }
}

@Composable
fun LogoMark(s: Dp) {
    val p = LocalPal.current
    Canvas(Modifier.size(s)) {
        val u = size.width / 64f
        drawRoundRect(Color(0xFF0D0E17), cornerRadius = CornerRadius(18f * u, 18f * u))
        drawRoundRect(
            p.brand, topLeft = Offset(2f * u, 2f * u), size = Size(60f * u, 60f * u),
            cornerRadius = CornerRadius(16f * u, 16f * u), style = Stroke(2.5f * u)
        )
        val segs = listOf(
            floatArrayOf(22f, 16f, 22f, 28f), floatArrayOf(16f, 22f, 28f, 22f), floatArrayOf(36f, 22f, 48f, 22f),
            floatArrayOf(16f, 36f, 28f, 48f), floatArrayOf(28f, 36f, 16f, 48f),
            floatArrayOf(36f, 39f, 48f, 39f), floatArrayOf(36f, 45f, 48f, 45f)
        )
        for (g in segs) drawLine(p.brand, Offset(g[0] * u, g[1] * u), Offset(g[2] * u, g[3] * u), 4.5f * u, StrokeCap.Round)
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier.bounce(onClick).clip(shape)
            .background(if (sel) p.brand else SolidColor(p.ink.copy(alpha = 0.08f)))
            .border(1.dp, p.ink.copy(alpha = if (sel) 0f else 0.1f), shape)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(label, color = if (sel) Color.White else p.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

// ---------------------------------------------------------------- keys
data class K(val l: String, val v: String, val k: Int = 0, val icon: ImageVector? = null)

private val CLEAR = K("AC", "AC", 3)

@Composable
fun Key(
    label: String, kind: Int, modifier: Modifier, fs: Int, idx: Int, icon: ImageVector?,
    onLong: (() -> Unit)?, onTap: () -> Unit
) {
    val p = LocalPal.current
    val hap = LocalHapticFeedback.current
    var down by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (down) 0.9f else 1f, spring(dampingRatio = 0.5f, stiffness = 700f), label = "sc")
    val glow by animateFloatAsState(if (down) 1f else 0f, tween(if (down) 50 else 500), label = "gl")
    val tap by rememberUpdatedState(onTap)
    val lng by rememberUpdatedState(onLong)
    val intro = remember { Animatable(if (idx >= 0) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (idx >= 0) {
            delay(1000L + idx * 26L)
            intro.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        }
    }
    val shim = if (kind == 4) {
        rememberInfiniteTransition(label = "sh").animateFloat(
            0f, 1f,
            infiniteRepeatable(keyframes<Float> { durationMillis = 4600; 0f at 3000; 1f at 4600 }, RepeatMode.Restart),
            label = "shv"
        ).value
    } else 0f
    val shape = RoundedCornerShape(Cfg.radius.dp)
    val fill: Brush = when (kind) {
        4 -> p.brand
        1 -> Brush.verticalGradient(listOf(p.a1.copy(alpha = 0.32f), p.a1.copy(alpha = 0.14f)))
        else -> if (Cfg.glass) Brush.verticalGradient(listOf(p.ink.copy(alpha = 0.13f), p.ink.copy(alpha = 0.04f)))
        else Brush.verticalGradient(listOf(p.surf2, p.surf2))
    }
    val txt: Color = when (kind) {
        1 -> p.a2
        2 -> p.a2
        3 -> Color(0xFFFF6B7D)
        4 -> Color.White
        else -> p.ink
    }
    Box(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc; alpha = intro.value; translationY = (1f - intro.value) * 90f }
            .clip(shape)
            .background(fill)
            .border(1.dp, p.ink.copy(alpha = 0.10f + 0.35f * glow), shape)
            .drawWithContent {
                if (glow > 0f) drawRect(p.a2.copy(alpha = 0.22f * glow))
                drawContent()
                if (kind == 4) {
                    val x = size.width * (shim * 2.4f - 0.7f)
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.5f), Color.Transparent),
                            startX = x, endX = x + size.width * 0.6f
                        )
                    )
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        down = true
                        if (Cfg.haptics) hap.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        tryAwaitRelease()
                        down = false
                    },
                    onTap = { tap() },
                    onLongPress = lng?.let { f -> { _: Offset -> f() } }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) Icon(icon, null, tint = txt, modifier = Modifier.size(26.dp))
        else Text(label, color = txt, fontSize = fs.sp, fontWeight = if (kind == 0) FontWeight.Normal else FontWeight.Medium)
    }
}

@Composable
fun KeyGrid(
    keys: List<K>, cols: Int, modifier: Modifier, fs: Int, gap: Dp, fixedH: Dp?, intro: Boolean,
    label: (K) -> String = { it.l }, onKey: (K) -> Unit
) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(gap)) {
        keys.chunked(cols).forEachIndexed { r, row ->
            Row(
                if (fixedH != null) Modifier.fillMaxWidth().height(fixedH) else Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                row.forEachIndexed { c, k ->
                    val lg: (() -> Unit)? = if (k.v == "bk") fun() { onKey(CLEAR) } else null
                    Key(
                        label(k), k.k, Modifier.weight(1f).fillMaxHeight(), fs,
                        if (intro) r * cols + c else -1, k.icon, lg
                    ) { onKey(k) }
                }
            }
        }
    }
}

val PAD = listOf(
    K("AC", "AC", 3), K("( )", "par", 2), K("%", "%", 2), K("÷", "÷", 1),
    K("7", "7"), K("8", "8"), K("9", "9"), K("×", "×", 1),
    K("4", "4"), K("5", "5"), K("6", "6"), K("−", "−", 1),
    K("1", "1"), K("2", "2"), K("3", "3"), K("+", "+", 1),
    K("0", "0"), K(".", "."), K("⌫", "bk", 3, Icons.Rounded.Backspace), K("=", "eq", 4)
)

val SCI = listOf(
    K("Deg", "deg", 2), K("MC", "MC", 3), K("MR", "MR", 2), K("M+", "M+", 2), K("M−", "M−", 2),
    K("sin", "sin("), K("cos", "cos("), K("tan", "tan("), K("π", "π"), K("e", "e"),
    K("ln", "ln("), K("log", "log("), K("√", "√("), K("^", "^", 1), K("!", "!"),
    K("asin", "asin("), K("acos", "acos("), K("atan", "atan("), K("x²", "^2"), K("1/x", "^(−1)")
)

val CPAD = listOf(
    K("7", "7"), K("8", "8"), K("9", "9"), K("⌫", "bk", 3, Icons.Rounded.Backspace),
    K("4", "4"), K("5", "5"), K("6", "6"), K("AC", "AC", 3),
    K("1", "1"), K("2", "2"), K("3", "3"), K("±", "±", 2),
    K("0", "0"), K(".", "."), K("swap", "sw", 2, Icons.Rounded.SwapVert), K("copy", "cp", 1, Icons.Rounded.ContentCopy)
)

// ---------------------------------------------------------------- calculator display
@Composable
fun Display(st: CalcState, modifier: Modifier) {
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    Column(
        modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom
    ) {
        if (st.mem != 0.0) {
            Text(
                "M", color = p.a2, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start).clip(RoundedCornerShape(8.dp))
                    .background(p.a1.copy(alpha = 0.22f)).padding(horizontal = 9.dp, vertical = 2.dp)
            )
        }
        Text(
            if (st.res != null) pretty(st.saved) + " =" else "", color = p.dim, fontSize = 22.sp, maxLines = 1,
            modifier = Modifier.horizontalScroll(rememberScrollState(), reverseScrolling = true)
        )
        AnimatedContent(
            targetState = st.res ?: "",
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.CenterEnd,
            transitionSpec = { (slideInVertically(tween(380)) { it / 2 } + fadeIn(tween(380))) togetherWith fadeOut(tween(120)) },
            label = "main"
        ) { r ->
            val txt = if (r.isNotEmpty()) (if (st.bad) r else pretty(r)) else pretty(st.ex).ifEmpty { "0" }
            val big = if (r.isNotEmpty()) 76 else 68
            val fs = (big - maxOf(0, txt.length - 7) * 4).coerceAtLeast(30)
            Text(
                txt, fontSize = fs.sp, fontWeight = FontWeight.ExtraLight, maxLines = 1, softWrap = false,
                color = p.ink, textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
                    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                    .drawWithContent {
                        drawContent()
                        drawRect(Brush.horizontalGradient(listOf(p.a2, p.ink, p.ink)), blendMode = BlendMode.SrcIn)
                    }
                    .clickable {
                        val rr = st.res
                        if (rr != null && !st.bad) clip.setText(AnnotatedString(rr.replace('−', '-')))
                    }
            )
        }
        Text(
            st.preview, color = p.dim, fontSize = 28.sp, fontWeight = FontWeight.Light, maxLines = 1,
            modifier = Modifier.height(40.dp)
        )
    }
}

// ---------------------------------------------------------------- converter
@Composable
fun UnitCard(cv: CvState, top: Boolean, modifier: Modifier) {
    val p = LocalPal.current
    var open by remember { mutableStateOf(false) }
    val unit = if (top) cv.from else cv.to
    val value = if (top) pretty(cv.cs.replace('-', '−')) else pretty(fmt(cv.result()))
    val shape = RoundedCornerShape(Cfg.radius.dp + 4.dp)
    val fs = (46 - maxOf(0, value.length - 9) * 2).coerceAtLeast(24)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(p.ink.copy(alpha = 0.10f), p.ink.copy(alpha = 0.04f))))
            .border(if (top) 1.5.dp else 1.dp, if (top) p.a1 else p.ink.copy(alpha = 0.1f), shape)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Box {
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(p.a1.copy(alpha = 0.2f))
                    .clickable { open = true }.padding(start = 14.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(unit, color = p.a2, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = p.a2, modifier = Modifier.size(18.dp))
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(p.surf2)) {
                for (u in (UNITS[cv.cat]?.keys ?: emptySet())) {
                    DropdownMenuItem(
                        text = { Text(u, color = p.ink) },
                        onClick = {
                            if (top) cv.from = u else cv.to = u
                            open = false
                        }
                    )
                }
            }
        }
        Text(
            value, color = if (top) p.ink else p.a2, fontSize = fs.sp, fontWeight = FontWeight.ExtraLight,
            maxLines = 1, softWrap = false, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun Converter(cv: CvState, intro: Boolean, modifier: Modifier) {
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    var rot by remember { mutableStateOf(0f) }
    val rotA by animateFloatAsState(rot, tween(500, easing = FastOutSlowInEasing), label = "rot")
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (c in UNITS.keys) Chip(if (c == "Temp") "Temperature" else c, c == cv.cat) { cv.pick(c) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                UnitCard(cv, true, Modifier.weight(1f))
                UnitCard(cv, false, Modifier.weight(1f))
            }
            Box(
                Modifier.align(Alignment.Center).size(50.dp)
                    .bounce { rot += 180f; cv.press("sw") }
                    .clip(CircleShape).background(p.brand),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.SwapVert, null, tint = Color.White, modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = rotA })
            }
        }
        KeyGrid(CPAD, 4, Modifier.weight(1.55f), 28, 10.dp, null, intro) { k ->
            if (k.v == "cp") clip.setText(AnnotatedString(fmt(cv.result()).replace('−', '-')))
            else if (k.v == "sw") { rot += 180f; cv.press("sw") }
            else cv.press(k.v)
        }
    }
}
