package com.luxe.calc

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Cfg.load(this)
        Watch.load()
        Rates.restore()
        setContent { ProvidePal { App() } }
    }
}

@Composable
fun App() {
    val p = LocalPal.current
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !p.dark
            c.isAppearanceLightNavigationBars = !p.dark
        }
    }
    val st = remember { CalcState() }
    val cv = remember { CvState() }
    var tab by remember { mutableStateOf(0) }
    var hist by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var intro by remember { mutableStateOf(true) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1250); intro = false
        delay(2600); first = false
    }
    BackHandler(enabled = settings || hist) { if (hist) hist = false else settings = false }
    val tabs = listOf("Calculator", "Scientific", "Convert", "Markets", "Graph", "Age")

    Box(Modifier.fillMaxSize().background(p.bg)) {
        Scene(p.scene, p.a1, p.a2, p.a3, p.dark, Cfg.motion, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                LogoMark(32.dp)
                Spacer(Modifier.width(10.dp))
                Text("Calculator", color = p.ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconBtn(Icons.Rounded.History, false) { hist = true }
                Spacer(Modifier.width(8.dp))
                IconBtn(Icons.Rounded.Settings, false) { settings = true }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEachIndexed { i, t -> Chip(t, tab == i) { tab = i } }
            }
            Spacer(Modifier.height(8.dp))
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                transitionSpec = { (fadeIn(tween(350)) + slideInVertically(tween(450)) { it / 12 }) togetherWith fadeOut(tween(150)) },
                label = "tab"
            ) { t ->
                when (t) {
                    0 -> Column(Modifier.fillMaxSize()) {
                        Display(st, Modifier.weight(1f))
                        KeyGrid(padFor(Cfg.layout), 4, Modifier.weight(1.65f), 30, Cfg.gap.dp, null, first) { st.press(it.v) }
                    }
                    1 -> Column(Modifier.fillMaxSize()) {
                        Display(st, Modifier.weight(1f))
                        KeyGrid(
                            SCI, 5, Modifier.padding(bottom = 8.dp), 16, 7.dp, 42.dp, false,
                            label = { if (it.v == "deg") (if (Cfg.deg) "Deg" else "Rad") else it.l }
                        ) { st.press(it.v) }
                        KeyGrid(padFor(Cfg.layout), 4, Modifier.weight(1.45f), 26, Cfg.gap.dp, null, false) { st.press(it.v) }
                    }
                    2 -> Converter(cv, first, Modifier.fillMaxSize())
                    3 -> Markets(Modifier.fillMaxSize())
                    4 -> GraphTab(Modifier.fillMaxSize())
                    else -> AgeTab(Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        HistorySheet(hist, st) { hist = false }
        SettingsPage(settings) { settings = false }
        Intro(intro)
    }
}

@Composable
fun IconBtn(icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier.size(42.dp).bounce(onClick).clip(shape)
            .background(if (on) p.a1.copy(alpha = 0.35f) else p.ink.copy(alpha = 0.08f))
            .border(1.dp, p.ink.copy(alpha = 0.1f), shape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = p.ink, modifier = Modifier.size(21.dp)) }
}

@Composable
fun Intro(visible: Boolean) {
    val sc = remember { Animatable(0.3f) }
    val rot = remember { Animatable(-120f) }
    LaunchedEffect(Unit) {
        launch { sc.animateTo(1f, spring(0.55f, 90f)) }
        launch { rot.animateTo(0f, tween(900, easing = FastOutSlowInEasing)) }
    }
    AnimatedVisibility(
        visible, modifier = Modifier.fillMaxSize(), enter = EnterTransition.None,
        exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 1.2f)
    ) {
        Box(Modifier.fillMaxSize().background(Color(0xFF07070D)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.graphicsLayer {
                    scaleX = sc.value; scaleY = sc.value; rotationZ = rot.value
                    alpha = ((sc.value - 0.3f) / 0.5f).coerceIn(0f, 1f)
                }) { LogoMark(96.dp) }
                Spacer(Modifier.height(22.dp))
                Text("CALCULATOR", color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp, letterSpacing = 8.sp, fontWeight = FontWeight.Light)
            }
        }
    }
}

@Composable
fun HistorySheet(visible: Boolean, st: CalcState, onClose: () -> Unit) {
    val p = LocalPal.current
    AnimatedVisibility(visible, modifier = Modifier.fillMaxSize(), enter = fadeIn(tween(300)), exit = fadeOut(tween(300))) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
        )
    }
    AnimatedVisibility(
        visible, modifier = Modifier.fillMaxSize(),
        enter = slideInVertically(spring(0.8f, 300f)) { it }, exit = slideOutVertically(tween(350)) { it }
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val shape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(0.82f).clip(shape).background(p.surf)
                    .border(1.dp, p.ink.copy(alpha = 0.1f), shape).navigationBarsPadding().padding(18.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("History", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Chip("Clear all", false) { Cfg.history.clear(); Cfg.save() }
                }
                if (Cfg.history.isEmpty()) {
                    Text(
                        "No calculations yet.\nResults you finish with = are saved here.", color = p.dim, fontSize = 15.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 80.dp)
                    )
                }
                LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    items(Cfg.history.toList()) { h ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.End) {
                            Text(pretty(h.first), color = p.dim, fontSize = 17.sp, modifier = Modifier.clickable {
                                st.ex = h.first; st.res = null; st.bad = false; onClose()
                            })
                            Text(pretty(h.second), color = p.a2, fontSize = 30.sp, fontWeight = FontWeight.Light, modifier = Modifier.clickable {
                                st.ex = h.second; st.res = null; st.bad = false; onClose()
                            })
                            Spacer(Modifier.height(12.dp))
                            Box(Modifier.fillMaxWidth().height(1.dp).background(p.ink.copy(alpha = 0.08f)))
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- settings
@Composable
fun SettingsPage(visible: Boolean, onBack: () -> Unit) {
    val p = LocalPal.current
    var filter by remember { mutableStateOf(0) }
    AnimatedVisibility(
        visible, modifier = Modifier.fillMaxSize(),
        enter = slideInHorizontally(tween(450)) { it } + fadeIn(tween(450)),
        exit = slideOutHorizontally(tween(350)) { it } + fadeOut(tween(300))
    ) {
        Box(Modifier.fillMaxSize().background(p.bg)) {
            Scene(p.scene, p.a1, p.a2, p.a3, p.dark, Cfg.motion, Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(Icons.Rounded.ArrowBack, false, onBack)
                    Spacer(Modifier.width(14.dp))
                    Text("Settings", color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(THEMES.size.toString() + " themes", color = p.dim, fontSize = 12.sp)
                }
                val list = THEMES.filter {
                    when (filter) {
                        1 -> it.scene != 0
                        2 -> it.dark
                        3 -> !it.dark
                        else -> true
                    }
                }
                LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        Column {
                            Label("PREVIEW")
                            Row(Modifier.fillMaxWidth().height(66.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Key("7", 0, Modifier.weight(1f).fillMaxHeight(), 26, -1, null, null) {}
                                Key("÷", 1, Modifier.weight(1f).fillMaxHeight(), 28, -1, null, null) {}
                                Key("AC", 3, Modifier.weight(1f).fillMaxHeight(), 22, -1, null, null) {}
                                Key("=", 4, Modifier.weight(1f).fillMaxHeight(), 30, -1, null, null) {}
                            }
                        }
                    }
                    item {
                        Column {
                            Label("THEME")
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Chip("All", filter == 0) { filter = 0 }
                                Chip("Live", filter == 1) { filter = 1 }
                                Chip("Dark", filter == 2) { filter = 2 }
                                Chip("Light", filter == 3) { filter = 3 }
                            }
                            Text(
                                "Tap a theme and the whole app blends into it.", color = p.dim, fontSize = 12.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                    items(list.chunked(2)) { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            for (t in pair) {
                                val idx = THEMES.indexOf(t)
                                ThemeCard(t, Cfg.theme == idx, Modifier.weight(1f)) { Cfg.theme = idx; Cfg.save() }
                            }
                            if (pair.size < 2) Spacer(Modifier.weight(1f))
                        }
                    }
                    item {
                        Column {
                            Label("KEYS")
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.ink.copy(alpha = 0.07f)).padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Roundness", color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                Slider(
                                    value = Cfg.radius.toFloat(), onValueChange = { Cfg.radius = it.toInt() },
                                    onValueChangeFinished = { Cfg.save() }, valueRange = 8f..36f,
                                    modifier = Modifier.weight(1f).padding(start = 12.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = p.a2, activeTrackColor = p.a1, inactiveTrackColor = p.ink.copy(alpha = 0.15f)
                                    )
                                )
                            }
                        }
                    }
                    item {
                        Column {
                            Label("KEYPAD LAYOUT")
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Classic", "Phone", "Mirror", "Ops left").forEachIndexed { i, n ->
                                    Chip(n, Cfg.layout == i) { Cfg.layout = i; Cfg.save() }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            LayoutPreview()
                        }
                    }
                    item { SliderRow("Key spacing", Cfg.gap.toFloat(), 4f..18f, { Cfg.gap = it.toInt() }) { Cfg.save() } }
                    item {
                        Column {
                            Label("NUMBER FONT")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Default", "Serif", "Mono").forEachIndexed { i, n -> Chip(n, Cfg.font == i) { Cfg.font = i; Cfg.save() } }
                            }
                        }
                    }
                    item { SettingRow("Glass keys", "Translucent keys that show the background", Cfg.glass) { Cfg.glass = it; Cfg.save() } }
                    item { SettingRow("Live backgrounds", "Animated scenes. Turn off to save battery", Cfg.motion) { Cfg.motion = it; Cfg.save() } }
                    item { SettingRow("Haptic feedback", "A soft tick on every key", Cfg.haptics) { Cfg.haptics = it; Cfg.save() } }
                    item {
                        SettingRow("Degrees for angles", "Off uses radians for sin, cos, tan", Cfg.deg) {
                            Cfg.deg = it; Engine.deg = it; Cfg.save()
                        }
                    }
                    item {
                        Text(
                            "Calculator 1.0", color = p.dim, fontSize = 12.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Label(text: String) {
    val p = LocalPal.current
    Text(
        text, color = p.dim, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}

@Composable
fun SettingRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.ink.copy(alpha = 0.07f)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = p.dim, fontSize = 13.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = p.a1, checkedThumbColor = Color.White,
                uncheckedTrackColor = p.ink.copy(alpha = 0.15f), uncheckedThumbColor = p.dim,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

@Composable
fun ThemeCard(t: AppTheme, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val bw by animateDpAsState(if (sel) 3.dp else 1.dp, tween(250), label = "bw")
    Box(
        modifier.height(150.dp).bounce(onClick).clip(shape).background(t.bg)
            .border(bw, if (sel) t.a2 else t.dim.copy(alpha = 0.32f), shape)
    ) {
        Scene(t.scene, t.a1, t.a2, t.a3, t.dark, Cfg.motion, Modifier.matchParentSize())
        Column(Modifier.fillMaxSize().padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.name, color = t.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, modifier = Modifier.weight(1f))
                if (sel) Icon(Icons.Rounded.CheckCircle, null, tint = t.a2, modifier = Modifier.size(18.dp))
            }
            if (t.scene != 0) Text("LIVE", color = t.a2, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
            Spacer(Modifier.weight(1f))
            Text("1,234.5", color = t.ink, fontSize = 24.sp, fontWeight = FontWeight.Light, modifier = Modifier.align(Alignment.End))
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.align(Alignment.End).clip(RoundedCornerShape(12.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(t.a1, t.a2, t.a3)))
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            ) { Text("=", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.ink.copy(alpha = 0.07f)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Slider(
            value = value, onValueChange = onChange, onValueChangeFinished = onDone, valueRange = range,
            modifier = Modifier.weight(1f).padding(start = 12.dp),
            colors = SliderDefaults.colors(thumbColor = p.a2, activeTrackColor = p.a1, inactiveTrackColor = p.ink.copy(alpha = 0.15f))
        )
    }
}

@Composable
fun LayoutPreview() {
    val p = LocalPal.current
    Column(
        Modifier.fillMaxWidth(0.62f).clip(RoundedCornerShape(18.dp)).background(p.ink.copy(alpha = 0.06f)).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        padFor(Cfg.layout).chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { k ->
                    Box(
                        Modifier.weight(1f).height(28.dp).clip(RoundedCornerShape(9.dp))
                            .background(if (k.k == 4) p.brand else SolidColor(p.ink.copy(alpha = 0.12f))),
                        contentAlignment = Alignment.Center
                    ) { Text(if (k.v == "bk") "<" else k.l, color = if (k.k == 4) Color.White else p.ink, fontSize = 12.sp) }
                }
            }
        }
    }
}
