package com.luxe.calc

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Everything the user can change, kept as live state so the UI reacts instantly. */
object Cfg {
    private var sp: SharedPreferences? = null
    var theme by mutableStateOf(0)
    var radius by mutableStateOf(26)
    var glass by mutableStateOf(true)
    var haptics by mutableStateOf(true)
    var motion by mutableStateOf(true)
    var deg by mutableStateOf(true)
    var layout by mutableStateOf(0)
    var gap by mutableStateOf(10)
    var font by mutableStateOf(0)
    var indian by mutableStateOf(true)
    var accent by mutableStateOf(-1)
    val history = mutableStateListOf<Pair<String, String>>()

    fun load(c: Context) {
        val s = c.getSharedPreferences("calc", Context.MODE_PRIVATE)
        sp = s
        theme = s.getInt("theme", 0).coerceIn(0, THEMES.size - 1)
        radius = s.getInt("radius", 26)
        glass = s.getBoolean("glass", true)
        haptics = s.getBoolean("haptics", true)
        motion = s.getBoolean("motion", true)
        deg = s.getBoolean("deg", true)
        layout = s.getInt("layout", 0)
        gap = s.getInt("gap", 10)
        font = s.getInt("font", 0)
        indian = s.getBoolean("indian", true)
        accent = s.getInt("accent", -1)
        Engine.deg = deg
        history.clear()
        for (line in (s.getString("hist", "") ?: "").split("\n")) {
            val parts = line.split("\t")
            if (parts.size == 2) history.add(parts[0] to parts[1])
        }
    }

    fun save() {
        val s = sp ?: return
        s.edit()
            .putInt("theme", theme).putInt("radius", radius).putBoolean("glass", glass)
            .putBoolean("haptics", haptics).putBoolean("motion", motion).putBoolean("deg", deg).putInt("layout", layout).putInt("gap", gap).putInt("font", font).putBoolean("indian", indian).putInt("accent", accent)
            .putString("hist", history.joinToString("\n") { it.first + "\t" + it.second })
            .apply()
    }

    fun putStr(k: String, v: String) { sp?.edit()?.putString(k, v)?.apply() }

    fun getStr(k: String): String = sp?.getString(k, "") ?: ""

    fun addHistory(e: String, r: String) {
        history.add(0, e to r)
        while (history.size > 100) history.removeAt(history.size - 1)
        save()
    }
}

/** scene: 0 still, 1 aurora, 2 stars, 3 rain, 4 snow / petals */
class AppTheme(
    val name: String, val dark: Boolean, val scene: Int,
    val bg: Color, val surf: Color, val surf2: Color, val ink: Color, val dim: Color,
    val a1: Color, val a2: Color, val a3: Color
)

private fun th(n: String, d: Boolean, sc: Int, bg: Long, s: Long, s2: Long, ink: Long, dim: Long, a1: Long, a2: Long, a3: Long) =
    AppTheme(n, d, sc, Color(bg), Color(s), Color(s2), Color(ink), Color(dim), Color(a1), Color(a2), Color(a3))

val THEMES = listOf(
    th("Midnight", true, 1, 0xFF07070D, 0xFF14141F, 0xFF1E1E2E, 0xFFF4F4FB, 0xFF9A9AB5, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("AMOLED", true, 0, 0xFF000000, 0xFF101012, 0xFF1B1B1F, 0xFFFFFFFF, 0xFF8E8E93, 0xFF00E0FF, 0xFF4D7CFF, 0xFF9B5CFF),
    th("Daylight", false, 1, 0xFFF6F5FF, 0xFFFFFFFF, 0xFFECEAFB, 0xFF14142B, 0xFF6B6B88, 0xFF6D5BFF, 0xFFB04BFF, 0xFFFF5CA8),
    th("Rose Quartz", false, 1, 0xFFFFF5F8, 0xFFFFFFFF, 0xFFFFE6EE, 0xFF2B1620, 0xFF8A6577, 0xFFFF5C8A, 0xFFFF7A59, 0xFFFFB36B),
    th("Ocean", true, 1, 0xFF06111A, 0xFF0D1E2B, 0xFF143044, 0xFFEAF6FF, 0xFF86A5BA, 0xFF00B3FF, 0xFF00D4C0, 0xFF5CFFB1),
    th("Sunset", true, 1, 0xFF120A0C, 0xFF211215, 0xFF2E1A1E, 0xFFFFF1EC, 0xFFB89A95, 0xFFFF7A18, 0xFFFF4D6D, 0xFFC13BFF),
    th("Emerald", true, 1, 0xFF050E0A, 0xFF0C1C15, 0xFF142B21, 0xFFE9FFF4, 0xFF84AD9A, 0xFF1ED760, 0xFF00C2A8, 0xFF8BE04E),
    th("Neon", true, 2, 0xFF06060A, 0xFF101018, 0xFF171722, 0xFFF0F0F8, 0xFF8A8AA0, 0xFF00FFC2, 0xFF00A3FF, 0xFFC400FF),
    th("Galaxy", true, 2, 0xFF06030F, 0xFF100A1E, 0xFF1A1130, 0xFFF2ECFF, 0xFF9B8FBF, 0xFF7C4DFF, 0xFF00D4FF, 0xFFFF5CE1),
    th("Cosmos", true, 2, 0xFF05030D, 0xFF0E0A1C, 0xFF18122E, 0xFFF0EAFF, 0xFF9A8FC0, 0xFF9D4EDD, 0xFF5A189A, 0xFFFFB703),
    th("Monsoon", true, 3, 0xFF07101A, 0xFF0E1B28, 0xFF16283A, 0xFFE6F1FA, 0xFF8FA6BA, 0xFF4FC3F7, 0xFF00897B, 0xFF7C4DFF),
    th("Sakura", false, 4, 0xFFFFF7FA, 0xFFFFFFFF, 0xFFFFE9F1, 0xFF2A1620, 0xFF8B6A78, 0xFFFF6FA5, 0xFFFF9E6D, 0xFFC86DD7),
    th("Snow", false, 4, 0xFFF2F8FF, 0xFFFFFFFF, 0xFFE1EDFA, 0xFF14263A, 0xFF6E879C, 0xFF6FA8DC, 0xFF3D85C6, 0xFFA9C7E8),
    th("Copper", true, 1, 0xFF0E0A08, 0xFF1A1310, 0xFF261A14, 0xFFFFF3EA, 0xFFB39A8A, 0xFFE07A3F, 0xFFC2410C, 0xFFF59E0B),
    th("Ivory Gold", false, 1, 0xFFFFFDF6, 0xFFFFFFFF, 0xFFF6F0E2, 0xFF241F17, 0xFF8C8271, 0xFFB08D57, 0xFF7A5C2E, 0xFFD4AF37),
    th("Lava", true, 1, 0xFF0C0403, 0xFF1A0A06, 0xFF2A110A, 0xFFFFF0E8, 0xFFC09A88, 0xFFFF3D00, 0xFFFFA000, 0xFFD50000)
)

/** The palette actually on screen: every colour blends smoothly when the theme changes. */
class Pal(
    val dark: Boolean, val scene: Int,
    val bg: Color, val surf: Color, val surf2: Color, val ink: Color, val dim: Color,
    val a1: Color, val a2: Color, val a3: Color
) {
    val brand: Brush get() = Brush.linearGradient(listOf(a1, a2, a3))
}

val LocalPal = compositionLocalOf { THEMES[0].toPal() }

fun AppTheme.toPal() = Pal(dark, scene, bg, surf, surf2, ink, dim, a1, a2, a3)

@Composable
private fun ac(c: Color): Color = animateColorAsState(c, tween(650), label = "pal").value

@Composable
fun ProvidePal(content: @Composable () -> Unit) {
    val t = THEMES[Cfg.theme]
    val hue = Cfg.accent
    val c1 = if (hue >= 0) Color.hsv(hue.toFloat(), 0.7f, 1f) else t.a1
    val c2 = if (hue >= 0) Color.hsv(((hue + 35) % 360).toFloat(), 0.65f, 1f) else t.a2
    val c3 = if (hue >= 0) Color.hsv(((hue + 70) % 360).toFloat(), 0.6f, 1f) else t.a3
    val p = Pal(t.dark, t.scene, ac(t.bg), ac(t.surf), ac(t.surf2), ac(t.ink), ac(t.dim), ac(c1), ac(c2), ac(c3))
    CompositionLocalProvider(LocalPal provides p) { content() }
}

/** Animated background scenes, drawn on a single Canvas so they stay smooth. */
@Composable
fun Scene(scene: Int, a1: Color, a2: Color, a3: Color, dark: Boolean, motion: Boolean, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "scene")
    val live by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    val ph = if (motion) live else 0.25f
    val rnd = remember { List(70) { floatArrayOf(Random(it * 31 + 7).nextFloat(), Random(it * 17 + 3).nextFloat(), Random(it * 13 + 5).nextFloat()) } }
    val strength = if (dark) 1f else 0.6f
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (scene != 0) {
            val cols = listOf(a1, a2, a3)
            val alphas = listOf(0.34f, 0.26f, 0.16f)
            for (i in 0..2) {
                val ang = (ph + i / 3f) * 2f * PI.toFloat()
                val c = Offset(w * (0.5f + 0.42f * sin(ang + i)), h * (0.3f + 0.28f * cos(ang * 1f + i * 2f) + i * 0.18f))
                val r = (if (w > h) w else h) * 0.75f
                drawCircle(
                    Brush.radialGradient(listOf(cols[i].copy(alpha = alphas[i] * strength), Color.Transparent), c, r),
                    r, c
                )
            }
        }
        when (scene) {
            2 -> for (s in rnd) {
                val tw = 0.5f + 0.5f * sin((ph * 4f + s[2]) * 2f * PI.toFloat())
                drawCircle(Color.White.copy(alpha = 0.15f + 0.6f * tw), 1.2f + s[2] * 2.2f, Offset(s[0] * w, s[1] * h))
            }
            3 -> for (s in rnd) {
                val y = ((ph * 18f * (0.7f + s[2] * 0.6f) + s[1]) % 1f) * (h + 80f) - 40f
                val x = s[0] * w
                drawLine(a1.copy(alpha = 0.45f), Offset(x, y), Offset(x - 5f, y + 26f), 2f, StrokeCap.Round)
            }
            4 -> for (s in rnd) {
                val y = ((ph * 3f * (0.6f + s[2] * 0.8f) + s[1]) % 1f) * (h + 40f) - 20f
                val x = s[0] * w + 24f * sin((ph * 6f + s[2]) * 2f * PI.toFloat())
                drawCircle((if (dark) Color.White else a1).copy(alpha = 0.55f), 2.5f + s[2] * 4f, Offset(x, y))
            }
            else -> {}
        }
    }
}

fun fam(): FontFamily = when (Cfg.font) {
    1 -> FontFamily.Serif
    2 -> FontFamily.Monospace
    else -> FontFamily.Default
}
