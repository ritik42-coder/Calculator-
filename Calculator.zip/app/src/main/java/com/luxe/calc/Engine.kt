package com.luxe.calc

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

object Engine {
    var deg = true
    var xv = 0.0
    private val tok = Regex("""\d+\.?\d*|\.\d+|asin|acos|atan|sin|cos|tan|ln|log|[πex√+\-×÷^()%!]""")

    fun calc(s: String): Double {
        val t = tok.findAll(s.replace('−', '-').replace('*', '×').replace('/', '÷')).map { it.value }.toList()
        if (t.isEmpty()) throw IllegalStateException("empty")
        return Parser(t).parse()
    }

    private class Parser(val t: List<String>) {
        var p = 0
        private val implicit = Regex("""^([\d.πex(√]|asin|acos|atan|sin|cos|tan|ln|log)""")
        private fun pk(): String? = t.getOrNull(p)
        private fun nx(): String? { val k = t.getOrNull(p); p++; return k }
        private fun bad(): Nothing = throw IllegalStateException("bad")

        fun parse(): Double { val v = expr(); if (p < t.size) bad(); return v }

        private fun expr(): Double {
            var l = term()
            while (pk() == "+" || pk() == "-") {
                val o = nx()
                var r = term()
                if (t[p - 1] == "%") r *= l
                l = if (o == "+") l + r else l - r
            }
            return l
        }

        private fun term(): Double {
            var l = un()
            var run = true
            while (run) {
                val k = pk()
                if (k == null) run = false
                else if (k == "×") { nx(); l *= un() }
                else if (k == "÷") { nx(); l /= un() }
                else if (implicit.containsMatchIn(k)) l *= un()
                else run = false
            }
            return l
        }

        private fun un(): Double {
            if (pk() == "-") { nx(); return -un() }
            if (pk() == "+") { nx(); return un() }
            return pw()
        }

        private fun pw(): Double {
            val b = po()
            if (pk() == "^") { nx(); return b.pow(un()) }
            return b
        }

        private fun po(): Double {
            var v = at()
            while (pk() == "!" || pk() == "%") {
                v = if (nx() == "!") fact(v) else v / 100.0
            }
            return v
        }

        private fun fact(n: Double): Double {
            if (n < 0 || n % 1.0 != 0.0 || n > 170) return Double.NaN
            var r = 1.0
            var i = 2
            while (i <= n.toInt()) { r *= i.toDouble(); i++ }
            return r
        }

        private fun at(): Double {
            val k = nx() ?: bad()
            if (k[0].isDigit() || k[0] == '.') return k.toDouble()
            if (k == "π") return PI
            if (k == "e") return E
            if (k == "x") return xv
            if (k == "(") { val v = expr(); if (pk() == ")") nx(); return v }
            if (k == "√") return sqrt(at())
            if (pk() != "(") bad()
            return fn(k, at())
        }

        private fun fn(k: String, x: Double): Double {
            val d = deg
            val rad = if (d) x * PI / 180.0 else x
            fun z(v: Double): Double = if (abs(v) < 1e-12) 0.0 else v
            fun dg(v: Double): Double = if (d) v * 180.0 / PI else v
            return when (k) {
                "sin" -> z(sin(rad))
                "cos" -> z(cos(rad))
                "tan" -> if (d && abs(x % 180.0) == 90.0) Double.NaN else z(tan(rad))
                "asin" -> dg(asin(x))
                "acos" -> dg(acos(x))
                "atan" -> dg(atan(x))
                "ln" -> ln(x)
                "log" -> log10(x)
                else -> bad()
            }
        }
    }
}

fun fmt(v0: Double): String {
    if (v0 == 0.0) return "0"
    val bd = BigDecimal(v0).round(MathContext(12)).stripTrailingZeros()
    val a = abs(bd.toDouble())
    val s = if (a >= 1e15 || a < 1e-7) bd.toString().replace("E+", "×10^").replace("E", "×10^") else bd.toPlainString()
    return s.replace('-', '−')
}

private val numRe = Regex("""\d+(\.\d*)?""")
fun pretty(s: String): String = numRe.replace(s) { m ->
    val x = m.value
    val i = x.substringBefore('.')
    val f = if (x.contains('.')) "." + x.substringAfter('.') else ""
    grp(i) + f
}

val UNITS: Map<String, Map<String, Double>> = linkedMapOf(
    "Length" to linkedMapOf("m" to 1.0, "km" to 1000.0, "cm" to 0.01, "mm" to 0.001, "mi" to 1609.344, "yd" to 0.9144, "ft" to 0.3048, "in" to 0.0254, "nmi" to 1852.0),
    "Mass" to linkedMapOf("kg" to 1.0, "g" to 0.001, "mg" to 1e-6, "t" to 1000.0, "lb" to 0.45359237, "oz" to 0.028349523125, "st" to 6.35029318),
    "Temp" to linkedMapOf("°C" to 1.0, "°F" to 1.0, "K" to 1.0),
    "Area" to linkedMapOf("m²" to 1.0, "km²" to 1e6, "cm²" to 1e-4, "ha" to 1e4, "acre" to 4046.8564224, "ft²" to 0.09290304, "in²" to 6.4516e-4, "mi²" to 2589988.110336),
    "Volume" to linkedMapOf("L" to 1.0, "mL" to 0.001, "m³" to 1000.0, "gal" to 3.785411784, "qt" to 0.946352946, "cup" to 0.2365882365, "fl oz" to 0.0295735295625, "tbsp" to 0.01478676478125, "tsp" to 0.00492892159375),
    "Speed" to linkedMapOf("m/s" to 1.0, "km/h" to 1.0 / 3.6, "mph" to 0.44704, "kn" to 0.514444444, "ft/s" to 0.3048),
    "Time" to linkedMapOf("s" to 1.0, "ms" to 0.001, "min" to 60.0, "h" to 3600.0, "day" to 86400.0, "week" to 604800.0, "year" to 31557600.0),
    "Data" to linkedMapOf("bit" to 0.125, "B" to 1.0, "KB" to 1024.0, "MB" to 1048576.0, "GB" to 1073741824.0, "TB" to 1099511627776.0)
)
val DEFAULT_UNITS = mapOf(
    "Length" to ("m" to "ft"), "Mass" to ("kg" to "lb"), "Temp" to ("°C" to "°F"), "Area" to ("m²" to "ft²"),
    "Volume" to ("L" to "gal"), "Speed" to ("km/h" to "mph"), "Time" to ("h" to "min"), "Data" to ("MB" to "GB"), "Currency" to ("USD" to "INR")
)

fun convert(cat: String, from: String, to: String, v: Double): Double {
    if (cat == "Temp") {
        val c = when (from) { "°C" -> v; "°F" -> (v - 32) * 5 / 9; else -> v - 273.15 }
        return when (to) { "°C" -> c; "°F" -> c * 9 / 5 + 32; else -> c + 273.15 }
    }
    if (cat == "Currency") {
        val a = Rates.map[from]
        val b = Rates.map[to]
        return if (a == null || b == null) 0.0 else v / a * b
    }
    val m = UNITS[cat] ?: return v
    return v * (m[from] ?: 1.0) / (m[to] ?: 1.0)
}

private val TOP_CUR = listOf("INR", "USD", "EUR", "GBP", "AED", "JPY", "AUD", "CAD", "SGD", "CNY", "SAR", "PKR", "BDT", "NPR")

fun unitsOf(cat: String): List<String> {
    if (cat == "Currency") {
        val k = Rates.map.keys
        if (k.isEmpty()) return TOP_CUR
        return TOP_CUR.filter { it in k } + k.filter { it !in TOP_CUR }.sorted()
    }
    return UNITS[cat]?.keys?.toList() ?: emptyList()
}

private fun grp(i: String): String {
    if (!Cfg.indian || i.length <= 3) return i.reversed().chunked(3).joinToString(",").reversed()
    return i.dropLast(3).reversed().chunked(2).joinToString(",").reversed() + "," + i.takeLast(3)
}
