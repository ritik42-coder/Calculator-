package com.luxe.calc

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.math.BigDecimal
import java.math.MathContext

/** Plain-English input: "18% gst on 2400", "15 percent of 3200", "5 km to miles", "100 usd to inr". */
object Smart {
    private val alias: Map<String, Pair<String, String>> by lazy { build() }

    private fun build(): Map<String, Pair<String, String>> {
        val m = HashMap<String, Pair<String, String>>()
        for ((cat, us) in UNITS) for (u in us.keys) m[u.lowercase()] = cat to u
        fun a(cat: String, u: String, vararg names: String) { for (n in names) m[n] = cat to u }
        a("Length", "m", "meter", "metre", "meters", "metres")
        a("Length", "km", "kilometer", "kilometre", "kilometers", "kilometres", "kms")
        a("Length", "mi", "mile", "miles")
        a("Length", "ft", "feet", "foot")
        a("Length", "in", "inch", "inches")
        a("Length", "cm", "centimeter", "centimetre", "centimeters", "centimetres")
        a("Mass", "kg", "kilogram", "kilograms", "kilo", "kilos", "kgs")
        a("Mass", "g", "gram", "grams")
        a("Mass", "lb", "pound", "pounds", "lbs")
        a("Mass", "oz", "ounce", "ounces")
        a("Mass", "t", "tonne", "tonnes", "ton", "tons")
        a("Temp", "°C", "celsius", "centigrade")
        a("Temp", "°F", "fahrenheit")
        a("Temp", "K", "kelvin")
        a("Volume", "L", "liter", "litre", "liters", "litres", "ltr")
        a("Volume", "gal", "gallon", "gallons")
        a("Volume", "mL", "milliliter", "millilitre", "milliliters", "millilitres")
        a("Speed", "km/h", "kmph", "kph")
        a("Time", "h", "hr", "hrs", "hour", "hours")
        a("Time", "min", "mins", "minute", "minutes")
        a("Time", "s", "sec", "secs", "second", "seconds")
        a("Time", "day", "days")
        a("Time", "week", "weeks")
        a("Time", "year", "years")
        a("Data", "B", "byte", "bytes")
        a("Area", "acre", "acres")
        a("Area", "ha", "hectare", "hectares")
        a("Currency", "USD", "dollar", "dollars")
        a("Currency", "INR", "rupee", "rupees", "rs")
        a("Currency", "EUR", "euro", "euros")
        return m
    }

    private fun resolve(t0: String): Pair<String, String>? {
        val t = t0.trim().lowercase().replace(Regex("^(degrees?)\\s+"), "")
        for (x in listOf(t, t.removeSuffix("s"), t.removeSuffix("es"))) {
            val hit = alias[x]
            if (hit != null) return hit
            val up = x.uppercase()
            if (up.length == 3 && Rates.map.containsKey(up)) return "Currency" to up
        }
        return null
    }

    fun run(raw: String): Pair<String, String>? {
        var s = raw.lowercase().trim().replace("?", "").replace("₹", "")
        s = s.replace(Regex("^(what is|what's|calculate|compute|how much is|find)\\s+"), "")
        s = s.replace(Regex("(?<=\\d),(?=\\d{3})"), "")
        val gst = Regex("(\\d+(?:\\.\\d+)?)\\s*(?:%|percent)?\\s*gst\\s*(?:on|of)\\s*(\\d+(?:\\.\\d+)?)").find(s)
        if (gst != null) {
            val r = gst.groupValues[1].toDouble()
            val a = gst.groupValues[2].toDouble()
            val g = a * r / 100.0
            return Pair(raw.trim() + "  (total " + pretty(fmt(a + g)) + ")", fmt(g))
        }
        val un = Regex("^(?:convert\\s+)?(-?\\d+(?:\\.\\d+)?)\\s*([a-z°²³/ ]+?)\\s+(?:to|in|into)\\s+([a-z°²³/ ]+)$").find(s)
        if (un != null) {
            val v = un.groupValues[1].toDouble()
            val a = resolve(un.groupValues[2])
            val b = resolve(un.groupValues[3])
            if (a != null && b != null && a.first == b.first) {
                val r = convert(a.first, a.second, b.second, v)
                val out = if (a.first == "Currency") fmt(Math.round(r * 10000.0) / 10000.0) else fmt(r)
                return Pair(pretty(un.groupValues[1]) + " " + a.second + " to " + b.second, out)
            }
        }
        s = s.replace(Regex("(\\d+(?:\\.\\d+)?)\\s*(?:%|percent)\\s+of\\s+"), "\$1%×")
        val reps = listOf(
            "multiplied by" to "×", "divided by" to "÷", "to the power of" to "^", "to the power" to "^",
            "square root of" to "√", "squared" to "^2", "cubed" to "^3", "times" to "×", "into" to "×",
            "plus" to "+", "minus" to "−", "subtract" to "−", "less" to "−", "over" to "÷", "sqrt" to "√"
        )
        for ((a, b) in reps) s = s.replace(a, b)
        s = s.replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "×").replace(Regex("\\bpi\\b"), "π")
        s = s.replace(Regex("\\band\\b"), "+").replace(Regex("\\badd\\b"), "+")
        return try {
            val v = Engine.calc(s)
            if (v.isFinite()) Pair(raw.trim(), fmt(v)) else null
        } catch (e: Exception) { null }
    }
}

private fun plain(v: Double): String = BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()

/** Reduces an expression one operation at a time, so you can see how it was solved. */
fun stepsOf(e: String): List<String> {
    val v0 = try { Engine.calc(e) } catch (x: Exception) { Double.NaN }
    val one = if (v0.isFinite()) listOf(pretty(e), fmt(v0)) else listOf(pretty(e))
    if (e.any { it.isLetter() || it == '%' || it == '!' || it == 'π' || it == '√' }) return one
    val re = Regex("\\d+\\.?\\d*|\\.\\d+|[+\\-−×÷^()]")
    val toks = ArrayList<String>()
    var neg = false
    for (m in re.findAll(e.replace('−', '-'))) {
        val v = m.value
        val isNum = v[0].isDigit() || v[0] == '.'
        if (v == "-" && (toks.isEmpty() || toks.last() in listOf("+", "-", "×", "÷", "^", "("))) neg = true
        else if (neg) {
            if (!isNum) return one
            toks.add("-" + v)
            neg = false
        } else toks.add(v)
    }
    val out = ArrayList<String>()
    fun show() { out.add(pretty(toks.joinToString("").replace('-', '−'))) }
    show()
    var guard = 0
    while (toks.size > 1 && guard < 40) {
        guard++
        var s = 0
        var en = toks.size
        val close = toks.indexOf(")")
        if (close >= 0) {
            val open = toks.subList(0, close).lastIndexOf("(")
            if (open < 0) return one
            s = open + 1
            en = close
        }
        var idx = -1
        for (k in en - 1 downTo s) if (toks[k] == "^") { idx = k; break }
        if (idx < 0) for (k in s until en) if (toks[k] == "×" || toks[k] == "÷") { idx = k; break }
        if (idx < 0) for (k in s until en) if (toks[k] == "+" || toks[k] == "-") { idx = k; break }
        if (idx < 0) {
            if (close >= 0 && en - s == 1) { toks.removeAt(close); toks.removeAt(s - 1) } else break
        } else {
            if (idx == 0 || idx >= toks.size - 1) return one
            val a = toks[idx - 1].toDoubleOrNull()
            val b = toks[idx + 1].toDoubleOrNull()
            if (a == null || b == null) return one
            val r = when (toks[idx]) {
                "^" -> Math.pow(a, b)
                "×" -> a * b
                "÷" -> a / b
                "+" -> a + b
                else -> a - b
            }
            if (!r.isFinite()) return one
            toks[idx - 1] = plain(r)
            toks.removeAt(idx + 1)
            toks.removeAt(idx)
        }
        show()
    }
    return if (out.size < 2) one else out
}

@Composable
fun StepLine(i: Int, text: String, last: Boolean) {
    val p = LocalPal.current
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(i * 220L)
        a.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
    }
    Text(
        (if (i == 0) "" else "=  ") + text, color = if (last) p.a2 else p.ink,
        fontSize = if (last) 26.sp else 20.sp, fontWeight = if (last) FontWeight.SemiBold else FontWeight.Light,
        modifier = Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 24f }
    )
}

@Composable
fun StepsDialog(expr: String, onDismiss: () -> Unit) {
    val p = LocalPal.current
    val lines = remember(expr) { stepsOf(expr) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = p.surf,
        title = { Text("How it was solved", color = p.ink) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                lines.forEachIndexed { i, l -> StepLine(i, l, i == lines.size - 1) }
            }
        },
        confirmButton = { Text("Close", color = p.a2, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onDismiss() }.padding(12.dp)) }
    )
}

@Composable
fun AskDialog(st: CalcState, onDismiss: () -> Unit) {
    val p = LocalPal.current
    var t by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    fun submit(x: String) {
        val r = Smart.run(x)
        if (r == null) {
            err = true
        } else {
            st.saved = r.first
            st.res = r.second
            st.bad = false
            st.ex = ""
            Cfg.addHistory(r.first, r.second)
            st.tape.add(r.first to r.second)
            onDismiss()
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val l = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (l != null && l.isNotEmpty()) {
            t = l[0]
            submit(l[0])
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = p.surf,
        title = { Text("Ask anything", color = p.ink) },
        text = {
            Column {
                Text("Try: 18% gst on 2400, 15 percent of 3200, 5 km to miles, 100 usd to inr", color = p.dim, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = t, onValueChange = { t = it; err = false }, singleLine = true,
                    textStyle = TextStyle(color = p.ink, fontSize = 18.sp), colors = fieldColors()
                )
                if (err) Text("I could not understand that. Try rephrasing.", color = DOWN, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(10.dp))
                Chip("Speak", false) {
                    try {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a calculation")
                        launcher.launch(i)
                    } catch (e: Exception) {
                        err = true
                    }
                }
            }
        },
        confirmButton = {
            Text("Calculate", color = p.a2, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { submit(t) }.padding(12.dp))
        },
        dismissButton = { Text("Cancel", color = p.dim, modifier = Modifier.clickable { onDismiss() }.padding(12.dp)) }
    )
}
