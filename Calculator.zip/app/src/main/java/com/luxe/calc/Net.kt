package com.luxe.calc

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class Quote(
    val sym: String, val name: String, val cur: String, val price: Double, val prev: Double,
    val closes: List<Double>, val times: List<Long>
) {
    val chg: Double get() = price - prev
    val pct: Double get() = if (prev != 0.0) (price - prev) / prev * 100.0 else 0.0
}

fun px(v: Double): String = String.format(Locale.US, if (kotlin.math.abs(v) >= 100) "%,.2f" else "%,.4f", v)

object Net {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Yahoo Finance chart data: stocks, indices, crypto, commodities, forex. */
    suspend fun quote(sym: String, range: String, interval: String, dayChange: Boolean): Quote? =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://query1.finance.yahoo.com/v8/finance/chart/" + URLEncoder.encode(sym, "UTF-8") +
                    "?range=" + range + "&interval=" + interval
                val res = JSONObject(get(url)).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
                val meta = res.getJSONObject("meta")
                val arr = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close")
                val ts = res.getJSONArray("timestamp")
                val closes = ArrayList<Double>()
                val times = ArrayList<Long>()
                for (i in 0 until arr.length()) {
                    if (!arr.isNull(i)) {
                        closes.add(arr.getDouble(i))
                        times.add(ts.getLong(i))
                    }
                }
                if (closes.size < 2) {
                    null
                } else {
                    val price = meta.optDouble("regularMarketPrice", closes.last())
                    val prev = if (dayChange) closes[closes.size - 2] else closes.first()
                    val name = meta.optString("shortName", meta.optString("longName", sym))
                    Quote(sym, name, meta.optString("currency", ""), price, prev, closes, times)
                }
            } catch (e: Exception) {
                null
            }
        }
}

object Rates {
    var map by mutableStateOf<Map<String, Double>>(emptyMap())
    var updated by mutableStateOf("")
    var loading by mutableStateOf(false)

    fun parse(s: String): Boolean {
        try {
            val j = JSONObject(s)
            val r = j.getJSONObject("rates")
            val m = HashMap<String, Double>()
            val ks = r.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                m[k] = r.getDouble(k)
            }
            if (m.isEmpty()) return false
            map = m
            updated = j.optString("time_last_update_utc", "").take(16)
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun restore() {
        val s = Cfg.getStr("rates")
        if (s.isNotEmpty()) parse(s)
    }

    suspend fun refresh() {
        loading = true
        try {
            val s = withContext(Dispatchers.IO) { Net.get("https://open.er-api.com/v6/latest/USD") }
            if (parse(s)) Cfg.putStr("rates", s)
        } catch (e: Exception) {
        } finally {
            loading = false
        }
    }
}

object Watch {
    val list = mutableStateListOf<String>()
    private val def = listOf("^NSEI", "^BSESN", "RELIANCE.NS", "TCS.NS", "AAPL", "TSLA", "NVDA", "BTC-USD", "ETH-USD", "GC=F", "USDINR=X")

    fun load() {
        list.clear()
        val s = Cfg.getStr("watch")
        list.addAll(if (s.isBlank()) def else s.split(",").filter { it.isNotBlank() })
    }

    private fun save() { Cfg.putStr("watch", list.joinToString(",")) }

    fun add(s: String) {
        val t = s.trim().uppercase()
        if (t.isNotEmpty() && t !in list) { list.add(t); save() }
    }

    fun remove(s: String) { list.remove(s); save() }
}
