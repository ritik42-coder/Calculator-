# Calculator (native Kotlin / Jetpack Compose)
Upload this zip (or its contents) to a GitHub repo. Keep `.github/workflows/build.yml` in the repo.
Actions tab -> "Build Calculator APK" -> when green, open **Releases** (or the run's Artifacts) and download Calculator.apk.
